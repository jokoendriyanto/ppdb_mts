<?php
  include 'include/koneksi.php';
  include 'include/header.php';
?>

<div class="container" style="margin-top:100px;">
  <div class="row">

    <div class="col-md-4">
      <section class="daftar">
        <div class="panel panel-default" style="
        -webkit-box-shadow: 1px 2px 3px -1px rgba(64,64,64,0.5);
          -moz-box-shadow: 1px 2px 3px -1px rgba(64,64,64,0.5);
          box-shadow: 1px 2px 3px -1px rgba(64,64,64,0.5);
        padding:15px; border-radius:2px;  ">
          <div class="alert alert-info"> <b>Selamat datang di halaman pendaftaran</b> </div>

          <a href="form.php" class="btn btn-default"> Isi Formulir pendaftaran </a>
        </div>
      </section>
      <br>
    </div>

    <div class="col-md-8">
      <section class="data-siswa">
        <div class="panel panel-default" style="
        -webkit-box-shadow: 1px 2px 3px -1px rgba(64,64,64,0.5);
          -moz-box-shadow: 1px 2px 3px -1px rgba(64,64,64,0.5);
          box-shadow: 1px 2px 3px -1px rgba(64,64,64,0.5);
         padding:15px; border-radius:2px; ">

           <div class="alert alert-info"> <b>Anda bisa melihat daftar calon siswa yang telah mendaftar</b> </div>

          <div class="table-responsive" style="padding:10px;">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Nama</th>
                  <th>Asal Sekolah</th>
                  <th>Program</th>
                </tr>
              </thead>
              <tbody>

                <?php
                  $no = 1;
                  $query  = mysqli_query($conn, "SELECT * FROM tb_siswa ORDER BY id DESC");
                  while ($hasil = mysqli_fetch_array($query)) {
                ?>

                <tr>
                  <td><?php echo $no++; ?></td>
                  <td><?php echo $hasil['nama_peserta']; ?></td>
                  <td><?php echo $hasil['asal_sekolah']; ?></td>
                  <td><?php echo $hasil['program_pertama']; ?></td>
                </tr>

                <?php } ?>

              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>





  </div>
</div>


<script src="functions/jquery.js"></script>
<script src="functions/functions.js"></script>
<script src="functions/datatables.js"></script>
<script src="./assets/js/sweat-alert.js"></script>

<script src="./assets/js/jquery.js"></script>
<script src="./assets/js/bootstrap.min.js"></script>
