
<?php
	include_once ('include/koneksi.php');
	include_once ('include/header.php');
?>

<?php
	$query = mysqli_query($conn, "SELECT count(nama_peserta) as 'jumlah' FROM tb_siswa ");
	$hasil = mysqli_fetch_array($query);
	$jml   = $hasil['jumlah'];
?>

		<section id="home">
			<header class="masthead">
				<div class="container h-100">
					<div class="row h-100">
						<div class="col-lg-8 my-auto">
							<div class="header-content mx-auto">
								<h1 class="welcome">Selamat Pendaftaran Berhasil</h1>
								<?
include "koneksi.php";

$nisn = $_GET['id'];

$sql = mysql_query("select*from tb_siswa where nisn='$nisn'")or die(mysql_error());
$row=mysql_fetch_array($sql);

?>

<table width="80%" border="0" align="center">
  <tr>
    <td width="5%">&nbsp;</td>
    <td colspan="5"><span class="style1">Catat no peserta dan password dibawah ini, untuk melanjutkan klik</span> <a href="?module=login">Login </a></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="5"><span class="style1">Daftar sekali saja. Untuk mengubah/ edit data masuk lewat login dengan no peserta dan password dibawah ini </span></td>
  </tr>
  <tr>
    <td colspan="6">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">Nama</td>
    <td width="1%">:</td>
    <td width="81%"><?= $row['nama_peserta']?></td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">No. Peserta </td>
    <td>:</td>
    <td><?= $row['kode_pendaftar']?></td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">Password:</td>
    <td>:</td>
    <td><?= $row['tanggal_daftar']?></td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="4">&nbsp;</td>
    <td width="1%">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="5">Silahkan login dan melengkapi persyaratan selanjutnya </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="5">Jangan lupa mencatat nomor peserta dan password </td>
  </tr>
</table>

							  <div class="daftar-sekarang pull-left">
									<a href="daftar.php" class="btn btn-danger btn-daftar" style=" ">Daftar Sekarang</a>
							  </div>

							</div>
						</div>

					</div>



				</div>
			</header>


		</section>

		<section class="cara">
			<div class="container">
				<div class="row row-cara">

						<div class="col-md-4">
							<h4 style="color:white;"></h4>
						</div>
						<div class="col-md-4"> </div>
						<div class="col-md-4">
							
						</div>
				</div>
			</div>
		</section>




		<!-- <section class="saat-ini">
			<div class="container">
				<div class="row">
					<div class="col-md-3">
						<p>Saat ini sudah ada :</p>
					</div>
					<div class="col-md-3">
						<strong>120</strong> Pegumuman <br>
						<strong>20 </strong>  Berita
					</div>
					<div class="col-md-3">
						<strong>53</strong>  Kasus Masalah <br>
						<strong>223</strong> Perizinan
					</div>
				</div>
			</div>
		</section> -->




		<script src="functions/jquery.js"></script>
		<script src="functions/functions.js"></script>
		<script src="functions/datatables.js"></script>
		<script src="assets/js/sweat-alert.js"></script>

		<script src="./assets/js/bootstrap.min.js"></script>
		</body>
		</html>
