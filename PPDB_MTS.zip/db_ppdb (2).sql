-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 18, 2018 at 11:34 
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ppdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id` int(11) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `level` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id`, `nama`, `username`, `password`, `level`) VALUES
(5, 'Ade Mahendra', 'adem', '8b372a2d003dc7c6e3ca4c4420c88ea9', 1),
(6, 'Karyo Lecek', 'lecek', 'd693346eecbac6df2c48e3c34e94199f', 2),
(7, 'Nurrohman', 'nur', 'b55178b011bfb206965f2638d0f87047', 2),
(8, 'Nurrohman', 'nur', 'b55178b011bfb206965f2638d0f87047', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tb_nilai`
--

CREATE TABLE `tb_nilai` (
  `id` int(11) NOT NULL,
  `nama_peserta` varchar(200) NOT NULL,
  `id_peserta` int(11) NOT NULL,
  `no_pendaftaran` varchar(200) NOT NULL,
  `tanggal_daftar` varchar(50) NOT NULL,
  `asal_sekolah` text NOT NULL,
  `program_pertama` varchar(40) NOT NULL,
  `program_kedua` varchar(40) NOT NULL,
  `nilai_tes` text NOT NULL,
  `nilai_makhraj` text NOT NULL,
  `nilai_kelancaran` text NOT NULL,
  `nilai_hafalan` text NOT NULL,
  `nilai_tajwid` text NOT NULL,
  `nilai_kelas_4_smt_1` text NOT NULL,
  `nilai_kelas_4_smt_2` text NOT NULL,
  `nilai_kelas_5_smt_1` text NOT NULL,
  `nilai_kelas_5_smt_2` text NOT NULL,
  `nilai_kelas_6_smt_1` text NOT NULL,
  `rata_rata` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_nilai`
--

INSERT INTO `tb_nilai` (`id`, `nama_peserta`, `id_peserta`, `no_pendaftaran`, `tanggal_daftar`, `asal_sekolah`, `program_pertama`, `program_kedua`, `nilai_tes`, `nilai_makhraj`, `nilai_kelancaran`, `nilai_hafalan`, `nilai_tajwid`, `nilai_kelas_4_smt_1`, `nilai_kelas_4_smt_2`, `nilai_kelas_5_smt_1`, `nilai_kelas_5_smt_2`, `nilai_kelas_6_smt_1`, `rata_rata`) VALUES
(34, 'Ade Mahendra', 50, '17-18 / 01-17 / USR001', '17/01/2018', 'MI Muhammadiyah Miri', 'Program Boarding School ', 'Program Reguler', '90', '81', '90', '87', '80', '90', '90', '90', '90', '90', '90');

-- --------------------------------------------------------

--
-- Table structure for table `tb_siswa`
--

CREATE TABLE `tb_siswa` (
  `id` int(11) NOT NULL,
  `program_pertama` text NOT NULL,
  `program_kedua` text NOT NULL,
  `nama_peserta` varchar(255) NOT NULL,
  `nisn` int(11) NOT NULL,
  `asal_sekolah` varchar(100) NOT NULL,
  `tempat_lahir` varchar(200) NOT NULL,
  `tanggal_lahir` varchar(200) NOT NULL,
  `bulan_lahir` varchar(120) NOT NULL,
  `tahun_lahir` int(11) NOT NULL,
  `alamat` text NOT NULL,
  `kecamatan` varchar(150) NOT NULL,
  `kabupaten` varchar(150) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `umur` int(11) NOT NULL,
  `agama` varchar(50) NOT NULL,
  `nama_ayah` varchar(250) NOT NULL,
  `pekerjaan_ayah` varchar(100) NOT NULL,
  `nama_ibu` varchar(150) NOT NULL,
  `pekerjaan_ibu` varchar(100) NOT NULL,
  `alamat_rumah_ortu` text NOT NULL,
  `kecamatan_ortu` varchar(200) NOT NULL,
  `kabupaten_ortu` varchar(120) NOT NULL,
  `telp1` varchar(30) NOT NULL,
  `wa` varchar(50) NOT NULL,
  `nilai_kelas_4_smt_1` varchar(200) NOT NULL,
  `nilai_kelas_4_smt_2` varchar(200) NOT NULL,
  `nilai_kelas_5_smt_1` varchar(200) NOT NULL,
  `nilai_kelas_5_smt_2` varchar(200) NOT NULL,
  `nilai_kelas_6_smt_1` varchar(200) NOT NULL,
  `rata_rata_final` varchar(200) NOT NULL,
  `tanggal_daftar` varchar(50) NOT NULL,
  `nomor_pendaftaran` text NOT NULL,
  `kode_pendaftar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_siswa`
--

INSERT INTO `tb_siswa` (`id`, `program_pertama`, `program_kedua`, `nama_peserta`, `nisn`, `asal_sekolah`, `tempat_lahir`, `tanggal_lahir`, `bulan_lahir`, `tahun_lahir`, `alamat`, `kecamatan`, `kabupaten`, `jenis_kelamin`, `umur`, `agama`, `nama_ayah`, `pekerjaan_ayah`, `nama_ibu`, `pekerjaan_ibu`, `alamat_rumah_ortu`, `kecamatan_ortu`, `kabupaten_ortu`, `telp1`, `wa`, `nilai_kelas_4_smt_1`, `nilai_kelas_4_smt_2`, `nilai_kelas_5_smt_1`, `nilai_kelas_5_smt_2`, `nilai_kelas_6_smt_1`, `rata_rata_final`, `tanggal_daftar`, `nomor_pendaftaran`, `kode_pendaftar`) VALUES
(50, 'Program Boarding School ', 'Program Reguler', 'Ade Mahendra', 289347934, 'MI Muhammadiyah Miri', 'sukoharjo', '10', 'Maret', 2004, 'Miri RT.02 RW.02 Bulu Polokarto Sukoharjo', 'polokarto', 'sukoharjo', 'laki-laki', 14, 'Islam', 'Fulan', 'TNI Angkatan sawah', 'Fulanah', 'Ibu rumah tangga', 'Miri RT.02 RW.02 Bulu Polokarto Sukoharjo', 'polokarto', 'sukoharjo', '087776659889', '082266778877', '90', '90', '90', '90', '90', '90', '17/01/2018', '17-18 / 01-17 / USR001', 'USR001'),
(51, 'Program Boarding School ', 'Program Reguler', 'Fulan Junaedi', 2147483647, 'MI Muhammadiyah Miri', 'sukoahrjo', '9', 'April', 1999, 'polokarto', 'polokarto', 'sukoharjo', 'laki-laki', 19, 'Islam', 'fulan', 'TNI Angkatan sawah', 'fulanah', 'Ibu rumah tangga', 'polokarto', 'polokarto', 'sukoharjo', '01731823', '08103280', '90', '90', '90', '90', '90', '90', '18/01/2018', '17-18 / 01-18 / USR002', 'USR002');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_nilai`
--
ALTER TABLE `tb_nilai`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_siswa`
--
ALTER TABLE `tb_siswa`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tb_nilai`
--
ALTER TABLE `tb_nilai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `tb_siswa`
--
ALTER TABLE `tb_siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
