<?php
	include_once ('include/koneksi.php');
	include 'include/header.php';
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>PPDB MTSn Sukoharjo</title>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="keywords" content="">
		<meta name="description" content="">

    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="./assets/css/font-awesome.min.css">
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700,800' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="./assets/css/style.css">
		<link rel="stylesheet" href="./assets/css/formulir.css">
		<link rel="stylesheet" href="./assets/css/normalize.min.css">
    <link rel="stylesheet" href="./assets/css/daftar.css">
    <link rel="stylesheet" href="./assets/css/sweat-alert.css">
    <link rel="stylesheet" href="./assets/css/datatables.css">

    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css">
</head>
  <body style="height:auto; background-color:white; ">

    <!-- <nav class="navbar navbar-default navbar-fixed-top templatemo-nav" role="navigation">
			<div class="container">
				<div class="navbar-header">
					<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="icon icon-bar"></span>
						<span class="icon icon-bar"></span>
						<span class="icon icon-bar"></span>
					</button>
					<a href="#" class="navbar-brand">PPDB</a>
          <a href="#" class="navbar-brand second-brand">MTs Negeri Sukoharjo</a>

				</div>
				<div class="collapse navbar-collapse">
					<ul class="nav navbar-nav navbar-right text-uppercase">

						<li><a href="index.php">Home</a></li>
						<li><a href="daftar.php">Pendaftaran</a></li>

          </ul>
				</div>
			</div>
		</nav> -->



		<div class="container">
		<div class="page-header" style="margin-top:5px; margin-bottom:-5px;">
			<img src="assets/images/head.png" class="img-responsive" width="350">

			<?php
							$tglsemua = date("d/m/y");
							$program = "1718";
							$bulan   = date("m");
							$tanggal = date("d");
							$jam     = date("h");
							$menit     = date("i");
							$detik     = date("s");
							$kode    = 1;

							// membuat no urut user
							$query 			= mysqli_query($conn, "SELECT max(kode_pendaftar) as kodeUser FROM tb_siswa ");
							$data  			= mysqli_fetch_array($query);
							$kode			  = $data['kodeUser'];
							$noUrut     = (int) substr($kode, 3, 3);
							// bilangan yang diambil ini ditambah 1 untuk menentukan nomor urut berikutnya
							$noUrut++;
							// membentuk kode anggota baru
							// perintah sprintf("%03s", $noUrut); digunakan untuk memformat string sebanyak 3 karakter
							// misal sprintf("%03s", 12); maka akan dihasilkan '012'
							// atau misal sprintf("%03s", 1); maka akan dihasilkan string '001'
							$char        = "USR";
							$no					 = $char . sprintf("%03s", $noUrut);
							$noPendaftaran = $program . $bulan . $tanggal . $jam . $menit . $detik;

						?>



		</div>
		<div class="panel panel-success" style="border-color:#bdc3c7; border-width:1px;">
			<div class="panel-body">

				<!-- STEPPER
					Allows a user to complete steps in a given process.

							* Required base class: .stepper
							@param .active
							@param .completed
							@param .disabled

							Dependencies:
								//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css
								//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js
								//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js

					-->

				<div class="stepper">
					<ul class="nav nav-tabs" role="tablist">

						<li role="presentation" class="active">
							<a class="persistant-disabled" href="#stepper-step-1" data-toggle="tab" aria-controls="stepper-step-1" role="tab" title="Step 1">
								<span class="round-tab">1</span>
							</a>
						</li>
						<li role="presentation" class="disabled">
							<a class="persistant-disabled" href="#stepper-step-2" data-toggle="tab" aria-controls="stepper-step-2" role="tab" title="Step 2">
								<span class="round-tab">2</span>
							</a>
						</li>
						<li role="presentation" class="disabled">
							<a class="persistant-disabled" href="#stepper-step-3" data-toggle="tab" aria-controls="stepper-step-3" role="tab" title="Step 3">
								<span class="round-tab">3</span>
							</a>
						</li>
						<li role="presentation" class="disabled">
							<a class="persistant-disabled" href="#stepper-step-4" data-toggle="tab" aria-controls="stepper-step-4" role="tab" title="Complete">
								<span class="round-tab">4</span>
							</a>
						</li>
					</ul>
					<form action="functions/insert-user.php" method="get">
						<div class="tab-content">
                        <p align="center" class="alert-danger"><strong>SEMUA FORM WAJIB DIISI. HARAP MEGGUNAKAN HURUF BESAR. <BR>JIKA ADA FORM YANG BELUM BISA UNTUK DIISI GUNAKAN TANDA MINUS ( - )</strong></p>
<div class="tab-pane fade in active" role="tabpanel" id="stepper-step-1">

								<div class="col-md-6">
									<div class="form-group">
										<label>Pilihan Pertama :</label>
										<select class="form-control" name="programPertama" required>
											<option value="Program Khusus ">Program Khusus (PK)</option>
											<option value="Program Boarding School ">Program Boarding School (Tahfidzul Qur'an)</option>
											<option value="Program Peminatan">Program Peminatan (Full Day)</option>
											<option value="Program Reguler">Program Reguler </option>
										</select>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label>Pilihan Kedua :</label>
										<select class="form-control" name="programKedua" required>
											<option value="Program Khusus ">Program Khusus (PK)</option>
											<option value="Program Boarding School ">Program Boarding School (Tahfidzul Qur'an)</option>
											<option value="Program Peminatan">Program Peminatan (Full Day)</option>
											<option value="Program Reguler">Program Reguler </option>
										</select>
									</div>
								</div>

								<ul class="list-inline pull-right">
									<li>
										<a class="btn btn-primary next-step">Lanjut</a>
									</li>
								</ul>
							</div>
							<div class="tab-pane fade" role="tabpanel" id="stepper-step-2">


								<div class="form-group">

									<input type="hidden" name="tgl" value="<?php echo $tglsemua; ?>">
									<input type="hidden" name="nomorPendaftaran" value="<?php echo $noPendaftaran; ?>">
									<input type="hidden" name="noPendaftar" value="<?php echo $no; ?>">

									<div class="col-md-2">
										 <h4 >Nama Peserta </h4>
									</div>
									<div class="col-md-5">
										<input type="text" class="form-control" name="namaPeserta" required>
									</div> <br><br>

									<div class="col-md-2">
										 <h4 >NISN </h4>
									</div>
									<div class="col-md-5">
										<input type="text" class="form-control  " name="nisn" maxlength="12" required>
									</div> <br><br>

									<div class="col-md-2">
										 <h4 >Asal Sekolah </h4>
									</div>
									<div class="col-md-5">
										<input type="text" class="form-control  " name="asalSekolah" required>
									</div> <br><br>

									<div class="col-md-2">
										 <h4> Tempat lahir </h4>
									</div>
									<div class="col-md-3">
										<input type="text" class="form-control  " name="tempatLahir" placeholder="Misal : Sukoharjo" required>
									</div> <br><br>

									<div class="col-md-2">
										 <h4> Tanggal lahir </h4>
									</div>
									<div class="col-md-3">
                                    <select class="form-control" name="tanggalLahir" required>
											<option value="1">1</option>
											<option value="2">2</option>
											<option value="3">3</option>
											<option value="4">4</option>
											<option value="5">5</option>
											<option value="6">6</option>
											<option value="7">7</option>
											<option value="8">8</option>
											<option value="9">9</option>
											<option value="10">10</option>
											<option value="11">11</option>
											<option value="12">12</option>
											<option value="13">13</option>
											<option value="14">14</option>
											<option value="15">15</option>
											<option value="16">16</option>
											<option value="17">17</option>
											<option value="18">18</option>
											<option value="19">19</option>
											<option value="20">20</option>
											<option value="21">21</option>
											<option value="22">22</option>
											<option value="23">23</option>
											<option value="24">24</option>
											<option value="25">25</option>
											<option value="26">26</option>
											<option value="27">27</option>
											<option value="28">28</option>
											<option value="29">29</option>
											<option value="30">30</option>
											<option value="21">31</option>
										</select>
										
									</div> <br><br>

									<div class="col-md-2">
										 <h4> Bulan lahir </h4>
									</div>
									<div class="col-md-3">
										<select class="form-control" name="bulanLahir" required>
											<option value="Januari">Januari</option>
											<option value="Februari">Februari</option>
											<option value="Maret">Maret</option>
											<option value="April">April</option>
											<option value="Mei">Mei</option>
											<option value="Juni">Juni</option>
											<option value="Juli">Juli</option>
											<option value="Agustus">Agustus</option>
											<option value="September">Septermber</option>
											<option value="Oktober">Oktober</option>
											<option value="November">November</option>
											<option value="Desember">Desember</option>

										</select>
									</div> <br><br>

									<div class="col-md-2">
										 <h4> Tahun lahir </h4>
									</div>
									<div class="col-md-3">
                                    										<select class="form-control" name="tahunLahir" required>
											<option value="2000">2000</option>
											<option value="2001">2001</option>
											<option value="2002">2002</option>
											<option value="2003">2003</option>
											<option value="2004">2004</option>
											<option value="2005">2005</option>
											<option value="2006">2006</option>
											<option value="2007">2007</option>
											<option value="2008">2008</option>
											<option value="2009">2009</option>
											<option value="2010">2010</option>

										</select>
										
									</div> <br><br><br>

									<div class="col-md-2">
										 <h4 >Alamat Rumah </h4>
									</div>
									<div class="col-md-5">
										<input type="text" class="form-control  " name="alamat" required>
									</div> <br><br>

									<div class="col-md-2">
										 <h4 >Kecamatan </h4>
									</div>
									<div class="col-md-5">
										<input type="text" class="form-control  " name="kecamatan" required>
									</div> <br><br>

									<div class="col-md-2">
										 <h4 >Kabupaten</h4>
									</div>
									<div class="col-md-5">
										<input type="text" class="form-control  " name="kabupaten" required>
									</div> <br><br>

									<div class="col-md-2">
										 <h4 >Umur </h4>
									</div>
									<div class="col-md-5">
                                    <select class="form-control" name="umur" required>
											<option value="10">10</option>
											<option value="11">11</option>
											<option value="12">12</option>
											<option value="13">13</option>
											<option value="14">14</option>
											<option value="15">15</option>
											<option value="16">16</option>
										</select>
										
									</div> <br><br>

									<div class="col-md-2">
										 <h4 >Agama </h4>
									</div>
									<div class="col-md-5">
										<input type="text" class="form-control  " name="agama" value="Islam" required>
									</div> <br><br>

									<div class="col-md-2">
										 <h4 >Jenis Kelamin </h4>
									</div>
									<div class="col-md-10 col-jk">
										<form>
											<label class="radio-inline"><input type="radio" name="gender" value="laki-laki">Laki-laki</label>
											<label class="radio-inline"><input type="radio" name="gender" value="perempuan">Perempuan</label>
										</form>
									</div>
							</div>


								<ul class="list-inline pull-right">
									<li>
										<a class="btn btn-default prev-step">Back</a>
									</li>
									<li>
										<a class="btn btn-primary next-step">Lanjut</a>
									</li>
								</ul>
							</div>
							<div class="tab-pane fade" role="tabpanel" id="stepper-step-3">

								<div class="form-group">

										<div class="col-md-2">
											 <h4 >Nama Ayah </h4>
										</div>
										<div class="col-md-5">
											<input type="text" class="form-control  " name="namaAyah" required >
										</div> <br><br>

										<div class="col-md-2">
											 <h4 >Pekerjaan Ayah </h4>
										</div>
										<div class="col-md-5">
											<select class="form-control" name="pekerjaanAyah">
			                  <option>Pilih</option>
			                  <option value="pns">PNS</option>
			                  <option value="wiraswasta">Wiraswasta</option>
			                  <option value="pegawai swasta">Pegawai Swasta</option>
			                  <option value="petani">Petani</option>
			                  <option value="nelayan">Nelayan</option>
			                  <option value="buruh">Buruh</option>
			                  <option value="guru">Guru</option>
			                  <option value="dosen">Dosen</option>
			                  <option value="insinyur">Insinyur</option>
			                  <option value="seniman">Seniman</option>
			                  <option value="desainer">Desainer</option>
			                  <option value="programmer">Programmer</option>
			                  <option value="freelancer">Freelancer</option>
			                  <option value="ibu rumah tangga">Ibu rumah tangga</option>

			                </select>
										</div> <br><br>

										<div class="col-md-2">
											 <h4 >Nama Ibu </h4>
										</div>
										<div class="col-md-5">
											<input type="text" class="form-control  " name="namaIbu" required >
										</div> <br><br>

										<div class="col-md-2">
											 <h4 >Pekerjaan Ibu</h4>
										</div>
										<div class="col-md-5">
											<select class="form-control" name="pekerjaanIbu">
			                  <option>Pilih</option>
			                  <option value="pns">PNS</option>
			                  <option value="wiraswasta">Wiraswasta</option>
			                  <option value="pegawai swasta">Pegawai Swasta</option>
			                  <option value="petani">Petani</option>
			                  <option value="nelayan">Nelayan</option>
			                  <option value="buruh">Buruh</option>
			                  <option value="guru">Guru</option>
			                  <option value="dosen">Dosen</option>
			                  <option value="insinyur">Insinyur</option>
			                  <option value="seniman">Seniman</option>
			                  <option value="desainer">Desainer</option>
			                  <option value="programmer">Programmer</option>
			                  <option value="freelancer">Freelancer</option>
			                  <option value="ibu rumah tangga">Ibu rumah tangga</option>

			                </select>
										</div> <br><br>

										<div class="col-md-2">
											 <h4 >Alamat Rumah </h4>
										</div>
										<div class="col-md-5">
											<input type="text" class="form-control  " name="alamatOrtu" required >
											<p class="help-block"> Harus lengkap. Misal : Miri RT.02 RW.02, Bulu, Polokarto, Sukoharjo </p>
										</div> <br><br> <br><br><br>

										<div class="col-md-2">
											 <h4 >Kecamatan </h4>
										</div>
										<div class="col-md-5">
											<input type="text" class="form-control  " name="kecamatanOrtu" required>
										</div> <br><br>

										<div class="col-md-2">
											 <h4 >Kabupaten </h4>
										</div>
										<div class="col-md-5">
											<input type="text" class="form-control  " name="kabupatenOrtu" required>
										</div> <br><br>



										<div class="col-md-2">
											 <h4 >No Telp </h4>
										</div>
										<div class="col-md-5">
											<input type="text" class="form-control  " name="telp1" required >
											<p class="help-block"> Nomor telp yang dapat di hubungi 1 </p>
										</div>
										<div class="col-md-5">
											<input type="text" class="form-control  " name="wa"  >
											<p class="help-block text-danger"> Nomor WA </p>
										</div> <br><br>

						</div>

								<ul class="list-inline pull-right">
									<li>
										<a class="btn btn-default prev-step">Back</a>
									</li>
									<li>
										<a class="btn btn-primary next-step">Lanjut</a>
									</li>
								</ul>
							</div>
							<div class="tab-pane fade" role="tabpanel" id="stepper-step-4">

								<table class="table table-striped">
									<tr>
										<th colspan="2" style="text-align:center; background-color:#3498db; color:white;  ">Kelas 4</th>
										<th colspan="2" style="text-align:center; background-color:#3498db; color:white; ">Kelas 5</th>
										<th colspan="2" style="text-align:center; background-color:#3498db; color:white; ">Kelas 6</th>
										<th colspan="2" rowspan="2" style="text-align:center; background-color:#2980b9; color:white; "> Rata-rata Akhir </th>
									</tr>
									<tr>
										<td>semester 1</td>
										<td>semester 2</td>
										<td>semester 1</td>
										<td>semester 2</td>
										<td colspan="2">semester 1</td>
									</tr>

									<tr>
										<td><input type="text" class="form-control  " id="kelas4smt1" name="kelas4smt1"></td>
										<td><input type="text" class="form-control  " id="kelas4smt2" name="kelas4smt2"></td>

										<td><input type="text" class="form-control  " id="kelas5smt1" name="kelas5smt1"></td>
										<td><input type="text" class="form-control  " id="kelas5smt2" name="kelas5smt2"></td>

										<td><input type="text" class="form-control  " id="kelas6smt1" name="kelas6smt1"></td>

										<td colspan="2"><input type="text" class="form-control  " id="rataRata" name="rataRata"></td>
									</tr>

								</table>

								<input type="submit" name="daftar" value="DAFTAR" class="btn btn-danger" style="width:100%;">
                                <br>
                                <br>
								<ul class="list-inline pull-right">
									<li>
										<a class="btn btn-default prev-step">Back</a>
									</li>
								</ul>
							</div>
						</div>
					</form>

				</div>

			</div>
		</div>
		</div>





<script src="functions/jquery.js"></script>
<script src="functions.js"></script>

<script src="assets/js/datatables.js"></script>
<script src="assets/js/sweat-alert.js"></script>

<script src="assets/js/jquery.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/index.js"></script>
</body>
</html>
