<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>PPDB MTSn Sukoharjo</title>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="keywords" content="">
		<meta name="description" content="">

    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="./assets/css/font-awesome.min.css">
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700,800' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="./assets/css/style.css">
    <link rel="stylesheet" href="./assets/css/daftar.css">
    <link rel="stylesheet" href="./assets/css/sweat-alert.css">
    <link rel="stylesheet" href="./assets/css/datatables.css">

    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css">
  </head>
  <body style="height:auto;">

    <nav class="navbar navbar-default navbar-fixed-top templatemo-nav" role="navigation">
			<div class="container">
				<div class="navbar-header">
					<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="icon icon-bar"></span>
						<span class="icon icon-bar"></span>
						<span class="icon icon-bar"></span>
					</button>
					<a href="#" class="navbar-brand">PPDB</a>
          <a href="#" class="navbar-brand second-brand">MTs Negeri Sukoharjo</a>

				</div>
				<div class="collapse navbar-collapse">
					<ul class="nav navbar-nav navbar-right text-uppercase">

						<li><a href="index.php">Home</a></li>
						<li><a href="daftar.php">Pendaftaran</a></li>
                        <li><a href="#">Login Siswa</a></li>
           <li><a target="_blank" href="admin/">Administrator</a></li>
						<!-- <li><a href="#download">Laporkan</a></li>
						<li> <button id="login-atas" type="button" class="btn btn-info" name="button">Login</button> </li>
            <li> <button id="login-atas" type="button" class="btn btn-info" data-toggle="modal" data-target="#LoginPage" >Login</button> </li>
						<li> <button id="register-atas" type="button" class="btn btn-info" name="button" data-toggle="modal" data-target="#RegisterPage" >Register</button> </li> -->

          </ul>
				</div>
			</div>
		</nav>







    <!--  ########################## LOGIN MODAL #################################  -->


	<div id="LoginPage" class="modal fade" role="dialog">

		<form action="./model/login.php" method="post" enctype="multipart/form-data">

		<div class="modal-dialog">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Silahkan Login</h4>
				</div>
				<div class="modal-body">

					<div class="form-group">
					  <label for="username">Username</label>
					  <input type="text" class="form-control" name="username" placeholder="Username">
					</div>

					<div class="form-group">
					  <label for="password">Password</label>
					  <input type="text" class="form-control" name="password" placeholder="Password">
					</div>

					<button type="submit" name="login" class="btn btn-default" >Login</button>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>

		</div>

	</form>
	</div>


	<!--  ########################## REGISTER MODAL #################################  -->
