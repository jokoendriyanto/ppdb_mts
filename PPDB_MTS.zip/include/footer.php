<footer class="atas">
  <div class="container">
    <div class="row">

    </div>
  </div>
</footer>

<footer class="bawah">
  <div class="container">
    <div class="row">
      <div class="col-md-10" style="margin-top:13px;">
        <p>&copy; Mts Negeri Sukoharjo 2019 </p>
      </div>
    </div>
  </div>
</footer>



<script src="./functions/jquery.js"></script>
<script src="./functions/functions.js"></script>
<script src="./functions/datatables.js"></script>
<script src="./assets/js/sweat-alert.js"></script>

<script src="./assets/js/jquery.js"></script>
<script src="./assets/js/bootstrap.min.js"></script>
</body>
</html>
