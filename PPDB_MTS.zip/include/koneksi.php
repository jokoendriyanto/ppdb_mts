<?php

  $host = "localhost";
  $user = "root";
  $pass = "";
  $db   = "db_ppdb";

  $conn = mysqli_connect($host, $user, $pass, $db);

?>
