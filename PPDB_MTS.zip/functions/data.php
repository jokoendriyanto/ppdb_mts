  <?php
                  $no    = 1;
                  $query = mysqli_query($conn, "SELECT * FROM tb_siswa ORDER BY id DESC");
                  while ($data = mysqli_fetch_array($query)) {
                ?>