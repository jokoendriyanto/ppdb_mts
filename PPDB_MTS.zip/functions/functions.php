<?php
include '../include/koneksi.php';

session_start();

    function register () {
      error_reporting(0);
      global $conn;

      $nama   = $_POST['nama'];
      $user   = $_POST['username'];
      $pass   = md5($_POST['nama']);
      $no_hp  = $_POST['no_hp'];
      $email  = $_POST['email'];
      $usia   = $_POST['usia'];
      $alamat = $_POST['alamat'];

      // untuk foto profil
      $sumber      = $_FILES['gambar']['tmp_name'];
      $ekstensi    = explode(".", $nama);
      $nama_gambar = "user-".end($ekstensi);
      $upload      = move_uploaded_file($sumber, "../uploads/user/user-register/".$nama_gambar);

      if ($upload) {
        $sql = mysqli_query($conn, "INSERT INTO tb_user  VALUES('','$nama', '$user','$pass','$no_hp','$email','$usia','$alamat','$nama_gambar') ");
        if ($sql) {
          echo "<div class='alert alert-info'><strong>Selamat</strong>, Registrasi anda berhasil. Silahkan Login</div>";
        } else {
          echo "<script>alert('ada kesalahan');</script>";
        }
      } else {
        echo "gagal mengupload foto profil";
      }

    }


    if (isset($_POST['LoginDepan'])) {
      include '../include/koneksi.php';

      $user     = $_POST['username'];
      $passAsli = $_POST['password'];
      $pass     = md5($passAsli);

      $ambilData = mysqli_query($conn, "SELECT * FROM tb_user WHERE username='$user' AND password='$pass' ");
      $hasil     = mysqli_fetch_array($ambilData);
      if ($hasil['username'] == $user && $hasil['password'] == $pass ) {
        echo "bisa";
        $_SESSION['user_id'] = $hasil['id'];
        $_SESSION['user'] = $hasil['username'];
        $_SESSION['nama'] = $hasil['nama'];
      } else {
        echo "gagal";
      }

    }


    if (isset($_POST['LoginBelakang'])) {

      require_once '../include/koneksi.php';

      $user = trim($_POST['username']);
      $password = trim($_POST['password']);
      $pass = md5($password);

        $sql = mysqli_query($conn, "SELECT * FROM tb_user WHERE username='$user' AND password='$pass' ");
        $row = mysqli_fetch_array($sql);
        if($row['username'] == $user && $row['password'] == $pass){
          echo "bisa"; // ketika benar
          $_SESSION['user_id'] = $row['id'];
          $_SESSION['user'] = $row['username'];
          $_SESSION['nama'] = $row['nama'];
        }
        else{
          echo "gagal"; // Ketika salah
        }

    }


    // Pencarian
    if (isset($_POST['Search'])) {
      $keyword = $_POST['Keyword'];
      $cari = mysqli_query($conn, "SELECT * FROM tb_produk WHERE judul LIKE '%$keyword%' ");
    }


    //  -------- TAMPIL KATEGORI -----------
    if (isset($_POST['Kategori'])) {
      $lihatKategori = mysqli_query($conn, "SELECT * FROM tb_kategori");

      while ($hasil = mysqli_fetch_array($lihatKategori)) {
        $id_kategori  = $hasil['id_kategori'];
        $namaKategori = $hasil['nama_kategori'];
        $icon_kategori = $hasil['icon_kategori'];

        echo "

        <a href='./pages/produk-semua.php?kategori=$id_kategori' class='button-kategori' >
        <ul class='list-group list-kategori'>
          <li class='list-group-item'> <img width='22' src='./uploads/admin/kategori/$icon_kategori' style='margin-right:5px;'>    $namaKategori</li>
        </ul>
        </a>

        ";

      }
    }

    if (isset($_POST['KategoriBelakang'])) {

      $lihatKategoriBelakang = mysqli_query($conn, "SELECT * FROM tb_kategori");

      while ($hasil = mysqli_fetch_array($lihatKategoriBelakang)) {
        $id_kategori  = $hasil['id_kategori'];
        $namaKategori = $hasil['nama_kategori'];
        $icon_kategori = $hasil['icon_kategori'];

        echo "

        <a href='./pages/produk-semua.php?kategori=$id_kategori' id='JudulProduk' title='$id_kategori' class='button-kategori' >
        <ul class='list-group list-kategori'>
          <li class='list-group-item'> <img width='22' src='../uploads/admin/kategori/$icon_kategori' style='margin-right:5px;'>    $namaKategori</li>
        </ul>
        </a>

        ";

      }

    }


    //  -------- TAMPIL PRODUK DI HOME ----------- //
?>

<?php
    if (isset($_POST['lihatLaptop'])) {
      $getProduk   = mysqli_query($conn, "SELECT * FROM tb_produk WHERE id_kategori='K001' ORDER BY id DESC LIMIT 6");
      while ($hasil = mysqli_fetch_array($getProduk)) {

        $gambar = $hasil['gambar'];
        $judul = $hasil['judul'];
        $harga = $hasil['harga'];
        $diskon = $hasil['diskon'];
        $diskonFinal = 100-$diskon;
        $hargaAwal = $hasil['hargaAwal'];
        $hargaAkhir = $hasil['hargaAkhir'];
        $tipe  = $hasil['tipe_barang'];
?>



        <div class='col-md-2 col-produk'>

          <div class='panel panel-default panel-produk' id='panel-produk'>
          <div class='gambar-produk'>
            <img src='./uploads/admin/jual-barang/<?php echo $gambar ?>' class='img-responsive' >
          </div>
          <div class='produk-favorit'>
            <span class='badge badge-favorit'><?php echo $tipe; ?></span>
            <?php
              if ($diskon) {
                echo " <span class='badge badge-diskon'>Diskon $diskonFinal %</span> ";
              } else {

              }
            ?>
          </div>

          <div class='judul-produk'>
            <a  href='./pages/produk-lihat.php?produk=<?php echo $judul; ?>' data-toggle='tooltip' data-placement='bottom' title='Tooltip on top'><?php echo $judul; ?></a>
          </div>

          <div class='harga-produk'>
            Rp. <?php echo number_format($harga); ?>
          </div>

          <div class='beli-produk'>

          </div>

          </div>
        </div>


      <?php } ?>
      <?php } ?>




      <?php // buka kembali tag PHP nya


    //  -------- TAMPIL PRODUK HAPE DI HOME ----------- //
        if (isset($_POST['lihatHape'])) {
          $getProduk   = mysqli_query($conn, "SELECT * FROM tb_produk WHERE id_kategori='K002' ORDER BY id DESC LIMIT 6");
          while ($hasil = mysqli_fetch_array($getProduk)) {

            $gambar = $hasil['gambar'];
            $judul = $hasil['judul'];
            $harga = $hasil['harga'];
            $diskon = $hasil['diskon'];
            $diskonFinal = 100-$diskon;
            $hargaAwal = $hasil['hargaAwal'];
            $hargaAkhir = $hasil['hargaAkhir'];
            $tipe  = $hasil['tipe_barang'];
    ?>
            <div class='col-md-2 col-produk'>

              <div class='panel panel-default panel-produk' id='panel-produk'>
              <div class='gambar-produk'>
                <img src='./uploads/admin/jual-barang/<?php echo $gambar ?>' class='img-responsive' >
              </div>

              <div class='produk-favorit'>
                <span class='badge badge-favorit'><?php echo $tipe; ?></span>
                <?php
                  if ($diskon) {
                    echo " <span class='badge badge-diskon'>Diskon $diskonFinal %</span> ";
                  } else {
                  }
                ?>
              </div>
              <div class='judul-produk'>
                <a  href='./pages/produk-lihat.php?produk=<?php echo $judul; ?>' data-toggle='tooltip' data-placement='bottom' title='Tooltip on top'><?php echo $judul; ?></a>
              </div>
              <div class='harga-produk'>
                Rp. <?php echo number_format($harga); ?>
              </div>
              <div class='beli-produk'>
              </div>
              </div>

            </div>


          <?php } ?>
          <?php } ?>


    <?php // buka lagi tag PHP nya



    // ====================  PRODUK TERKAIT ==========================  //

    if (isset($_POST['produkTerkait'])) {
      $produk = mysqli_query($conn, "SELECT * FROM tb_produk LIMIT 6");
      while ($hasil  = mysqli_fetch_array($produk)) {
        $gambar = $hasil['gambar'];
        $judul = $hasil['judul'];
        $harga = $hasil['harga'];
        $diskon = $hasil['diskon'];
        $diskonFinal = 100-$diskon;
        $hargaAwal = $hasil['hargaAwal'];
        $hargaAkhir = $hasil['hargaAkhir'];
        $tipe  = $hasil['tipe_barang'];
    ?>

    <div class="col-md-6">
      <div class='panel panel-default panel-produk-terkait' id='panel-produk'>
      <div class='gambar-produk-terkait'>
        <img src='../uploads/admin/jual-barang/<?php echo $gambar ?>' class='img-responsive' >
      </div>

      <div class='produk-favorit-terkait'>
        <span class='badge badge-favorit'><?php echo $tipe; ?></span>
        <?php
          if ($diskon) {
            echo " <span class='badge badge-diskon-terkait'>Diskon $diskonFinal %</span> ";
          } else {
          }
        ?>
      </div>
      <div class='judul-produk-terkait'>
        <a  href='../pages/produk-lihat.php?produk=<?php echo $judul; ?>' data-toggle='tooltip' data-placement='bottom' title='Tooltip on top'><?php echo $judul; ?></a>
      </div>
      <div class='harga-produk-terkait'>
        Rp. <?php echo number_format($harga); ?>
      </div>
      <div class='beli-produk'>
      </div>
      </div>
    </div>

  <?php } ?>
<?php } ?>



    <?php // buka lagi tag php nya
    //  -------- TAMBAH PRODUK KE KERANJANG ----------- //

    if (isset($_POST['tambahKeranjang'])) {
        $produk_id = $_POST['produkId'];
        $user_id   = $_SESSION['user_id'];
        $sql1 = mysqli_query($conn, "SELECT * FROM tb_keranjang WHERE produk_id='$produk_id' AND user_id='$user_id'  ");
        $jumlah = mysqli_num_rows($sql1);

        if ($jumlah < 0) {
          echo "ora iso";
        } else {
          $sql = mysqli_query($conn, "SELECT * FROM tb_produk WHERE id='$produk_id' ");
          $hasil = mysqli_fetch_array($sql);

          $id  = $hasil['id'];
          $judul = $hasil['judul'];
          $gambar = $hasil['gambar'];
          $harga = $hasil['harga'];

          $masukkan_produk = " INSERT INTO `tb_keranjang` (`id`, `produk_id`, `ip_add`, `user_id`, `judul_produk`, `gambar_produk`, `jumlah`, `harga`, `total`)
                                VALUES (NULL, '$produk_id', '0', '$user_id', '$judul', '$gambar', '1', '$harga', '$harga'); ";

          if (mysqli_query($conn, $masukkan_produk)) {
            echo "berhasil di tambahkan ke keranjang";
          } else {
            echo "gagal menambah produk ke keranjang";
          }

        }
    }


    //  -------- LIHAT PRODUK DI HEADER ----------- //

      // keranjang depan
      if (isset($_POST['lihatKeranjangDepan'])) {
        error_reporting(0);
        if (!isset($_SESSION['user'])) {
          echo "<div class='alert alert-danger'>Anda belum login</div>";
        }
        $user_id = $_SESSION['user_id'];
        $cek = mysqli_query($conn, "SELECT * FROM tb_keranjang WHERE user_id='$user_id' LIMIT 5 ");
          while ( $hasil  = mysqli_fetch_array($cek)) {
            $judul = $hasil['judul_produk'];
            $harga = $hasil['harga'];
            $gambar = $hasil['gambar_produk'];
            echo "
            <ul class='list-group'>
              <li class='list-group-item'> <img width='60' src='./uploads/admin/jual-barang/$gambar'> | $judul</li>
            </ul>
            ";
          }
      }

      // count depan
      if (isset($_POST['count'])) {
        error_reporting(0);
        $user_id = $_SESSION['user_id'];
        $jumlah = mysqli_query($conn, "SELECT * FROM tb_keranjang WHERE user_id='$user_id' ");
        echo mysqli_num_rows($jumlah);
      }

      // keranjang belakang
      if (isset($_POST['lihatKeranjang'])) {
        error_reporting(0);
        if (!isset($_SESSION['user'])) {
          echo "<div class='alert alert-danger'>Anda belum login</div>";
        }
        $user_id = $_SESSION['user_id'];
        $cek = mysqli_query($conn, "SELECT * FROM tb_keranjang WHERE user_id='$user_id' LIMIT 5 ");
          while ( $hasil  = mysqli_fetch_array($cek)) {
            $judul = $hasil['judul_produk'];
            $harga = $hasil['harga'];
            $gambar = $hasil['gambar_produk'];
            echo "
            <ul class='list-group'>
              <li class='list-group-item'> <img width='60' src='../uploads/admin/jual-barang/$gambar'> | $judul</li>
            </ul>
            ";
          }
      }



    // Lihat semua produk di keranjang

    if (isset($_POST['lihatSemuaProduk'])) {
      error_reporting(0);
      $user_id = $_SESSION['user_id'];
      $ambil_produk = mysqli_query($conn, "SELECT * FROM tb_keranjang WHERE user_id='$user_id' ");
      $rows = mysqli_num_rows($ambil_produk);

      if (!isset($_SESSION['user_id'])) {
        echo "

        <div class='alert alert-danger' style='margin-top:20px;'>Anda belum login</div>

        ";
      }

      echo "
      <thead>
        <tr>
          <th>No</th>
          <th>Gambar</th>
          <th>Produk</th>
          <th>Harga</th>
          <th>Jumlah</th>
          <th>Sub total</th>
          <th>Pilihan</th>
        </tr>
      </thead>
      ";


      if ($rows > 0) {
        $no = 1;
        while ($hasil_keranjang = mysqli_fetch_array($ambil_produk)) {

            $id     = $hasil_keranjang['produk_id'];
            $jumlah    = $hasil_keranjang['jumlah'];
            $gambar = $hasil_keranjang['gambar_produk'];
            $judul  = $hasil_keranjang['judul_produk'];
            $harga  = $hasil_keranjang['harga'];
            $sub  = $hasil_keranjang['total'];

          echo "

          <tbody>
            <tr>
              <td>$no+1;</td>
              <td><img width='80' src='../uploads/admin/jual-barang/$gambar'></td>
              <td>$judul</td>
              <td><input type='text' class='form-control form-harga' value='$harga' disabled></td>

              <td>
              <div class='input-group' style='width:120px;'>
                <input type='text' class='form-control form-jumlah-produk' produk_id='$id' value='$jumlah'>
              </div>
              </td>

              <td><input type='text' id='sub' class='form-control form-total' value='$sub' style='width:150px;' disabled></td>

              <td>
              <button class='btn btn-default btn-update btn-sm' produk_id='$id' type='button'><i class='fa fa-refresh'></i></button>
              <button type='button' class='btn btn-danger btn-sm btn-delete' produk_id='$id'><i class='fa fa-trash-o'></i></button>
              </td>
            </tr>

          </tbody>

          ";


        }

      }

    }


    if (isset($_POST['TotalHarga'])) {
      error_reporting(0);
      $user_id = $_SESSION['user_id'];
      $ambil_produk = mysqli_query($conn, "SELECT SUM(total) as total FROM tb_keranjang WHERE user_id='$user_id' ");
      $rows = mysqli_num_rows($ambil_produk);

        while ($hasil_keranjang = mysqli_fetch_array($ambil_produk)) {

            $total = $hasil_keranjang['total'];
            $_SESSION['TotalHarga'] = $total;

          echo "

          <input type='text' class='form-control pull-right' value='Total : $total' style='width:150px; margin-right:-10px;' disabled>

          ";

        }
    }


    // hapus produk
    if (isset($_POST['HapusProdukDariKeranjang']) ) {
      $id = $_POST['idProduk'];
      $user_id = $_SESSION['user_id'];

      $delete_produk = mysqli_query($conn, "DELETE FROM tb_keranjang WHERE produk_id='$id' AND user_id='$user_id' ");
      if ($delete_produk) {
        echo "berhasil di hapus";
      } else {
        echo "gagal di hapus";
      }

    }


    // Update produk di keranjang
    if (isset($_POST['EditProdukDariKeranjang']) ) {

      $produk_id     = $_POST['EditId'];
      $user_id  = $_SESSION['user_id'];
      $harga  = $_POST['Harga'];
      $jumlah = $_POST['Jumlah'];
      $total  = $_POST['Total'];


      $edit = mysqli_query($conn, " UPDATE tb_keranjang SET harga='$harga', jumlah='$jumlah', total='$total' WHERE user_id='$user_id' AND produk_id='$produk_id'  ");

      if ($edit) {
        echo "berhasil di update";
      } else {
        echo "gagal di update";
      }

    }



 // =====================================================================================================================================
 // ====================================================== PESAN BARANG ================================================================
 // ===================================================================================================================================



     if (isset($_POST['LihatDetailUser'])) {
       $user_id = $_SESSION['user_id'];
       $getUser = mysqli_query($conn, "SELECT * FROM tb_user WHERE id ='$user_id' ");

       while ( $hasil = mysqli_fetch_array($getUser) ) {
         $nama = $hasil['nama'];
         $telp = $hasil['nomor_hp'];
         $email = $hasil['email'];

         echo "

            <label for='nama' class='label-form'>Nama Lengkap</label>
            <input type='text' name='nama' class='form-control' id='nama' placeholder='Nama Lengkap' value='$nama'>

            <label for='nomor_hp' class='label-form'>No. Telp</label>
            <input type='text' name='nomor_hp' class='form-control' id='nomor_hp' placeholder='No. Telp' value='$telp'>

            <label for='email' class='label-form'>Email</label>
            <input type='text' name='email' class='form-control' id='email' placeholder='Email' value='$email'>

         ";

       }

     }


     if (isset($_POST['LihatDetailProduk'])) {
       error_reporting(0);
       $user_id = $_SESSION['user_id'];

       if (!isset($_SESSION['TotalHarga'])) {
         echo "<script>window.location.href='../index.php';</script>";
       }

       $getDetail = mysqli_query($conn, "SELECT * FROM tb_keranjang WHERE user_id = '$user_id'  ");
         while ($hasil = mysqli_fetch_array($getDetail)) {

           $id     = $hasil['produk_id'];
           $gambar = $hasil['gambar_produk'];
           $produk = $hasil['judul_produk'];
           $jumlah = $hasil['jumlah'];
           $harga  = $hasil['total'];
           $subHarga = $_SESSION['TotalHarga'];
           $hargaFinal = number_format($subHarga);

           echo "
             <tr>
               <td>1</td>
               <td id='gambarProduk' gambar_produk='$gambar'><img width='80' src='../uploads/admin/jual-barang/$gambar'></td>
               <td id='namaProduk' nama_produk='$produk'>$produk</td>
               <td id='jumlah' jumlah_produk='$jumlah'>$jumlah</td>
               <td>Rp. $harga</td>

             </tr>
           ";

         }

         echo "

         <tr>
          <td></td>
          <td></td>
          <td></td>
          <td><strong>Total Harga </strong></td>
          <td id='SubHarga' subHarga_produk='$subHarga'>Rp. $hargaFinal</td>
         </tr>

         ";


     }



     // pesan barang sekarang

     if (isset($_POST['BeliSekarang'])) {
       $user_id = $_SESSION['user_id'];
       // mengambil nama,email,nomor, dan alamat dari form
       $nama     = $_POST['Nama'];
       $nomor    = $_POST['Nomor'];
       $email    = $_POST['Email'];
       $alamat   = $_POST['Alamat'];

       $getProduk = mysqli_query($conn, "SELECT * FROM tb_keranjang WHERE user_id = '$user_id'  ");

       while ($hasil = mysqli_fetch_array($getProduk)) {
         $id     = $hasil['produk_id'];
         $produk = $hasil['judul_produk'];
         $gambar = $hasil['gambar_produk'];
         $jumlah = $hasil['jumlah'];
         $harga  = $hasil['total'];
         $subHarga = $_SESSION['TotalHarga'];

         $beli = mysqli_query($conn, "INSERT INTO tb_pesan VALUES ('','$produk','$gambar','$jumlah','$harga','$nama','$nomor','$email','$alamat')");
         if ($beli) {
           echo "Transaksi berhasil";
         } else {
           echo "Ada kesalahan";
         }

       }

     }

     // hapus produk dari keranjang setelah produk berhasil di beli
     if (isset($_POST['HapusProdukDiKeranjang'])) {
       $user_id = $_SESSION['user_id'];
       $id = $_POST['ProdukId'];

       $hapus = mysqli_query($conn, "DELETE FROM tb_keranjang WHERE user_id='$user_id'  ");

       if ($hapus) {
         echo "iso di hapus";
       } else {
         echo "ora iso";
       }

     }


?>





  <?php

  // =====================================================================================================================================
  // ====================================================== DASHBOARD ================================================================
  // ===================================================================================================================================


  if (isset($_POST['LoginDulu'])) {
    if (isset($_SESSION['user_id'])) {
      echo "  <div id='welcomeLogin' class='alert alert-info alert-dashboard'><b>Hai Ade Mahendra,</b> Selamat datang di <s>Alfamart</s> halaman Dashboard kamu  </div> <br> ";

    } else {
      echo " <div id='welcomeLogin' class='alert alert-danger alert-dashboard'><b>Hai Ade Mahendra,</b> kamu belum login lho..</div> <br> ";
    }
  }


  //  <!--Bagian User Info  -->
     if (isset($_POST['UserInfo'])) {
       error_reporting(0);
       $user_id = $_SESSION['user_id'];
       $user = mysqli_query($conn, "SELECT * FROM tb_user WHERE id='$user_id' ");

       while ($hasil = mysqli_fetch_array($user)) {
         $nama = $hasil['nama'];
         $foto = $hasil['foto'];
  ?>


    <div class="foto-profil" id="fotoProfil">
      <img src="../uploads/user/user-register/<?php echo $foto; ?>" class="img-responsive">
    </div>
    <div class="nama-profil" id="namaProfil">
      <h4><?php echo $nama; ?></h4>
    </div>

        <!-- tutup if sama while -->
       <?php } ?>
     <?php } ?>



<?php
  if (isset($_POST['Transaksi'])) {
    error_reporting(0);
    $nama    = $_SESSION['nama'];
    $user_id = $_SESSION['user_id'];
    $Transaksi = mysqli_query($conn, "SELECT * FROM tb_pesan WHERE nama = '$nama'  ");

    while ($hasil = mysqli_fetch_array($Transaksi)) {
?>

      <div class="table-responsive">
      <table class="table table-striped">
      <thead>
        <tr>
          <th>No.</th>
          <th>Produk</th>
          <th>Gambar</th>
          <th>Jumlah</th>
          <th>Harga</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td><?php echo $hasil['produk']; ?></td>
          <td><img src="../uploads/admin/jual-barang/<?php echo $hasil['gambar']; ?> " class="img-responsive" width="80"></td>
          <td><?php echo $hasil['jumlah']; ?></td>
          <td><?php echo $hasil['sub_harga']; ?></td>
        </tr>
      </tbody>
      </table>
      </div>




<?php
  } // tutup if
  } // tutup while
?>
