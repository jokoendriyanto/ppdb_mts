<?php
include_once('../include/koneksi.php');

  if (isset($_GET['daftar'])) {



    $programPertama 		= strtoupper($_GET['programPertama']);
    $programKedua 			= strtoupper($_GET['programKedua']);
    $namaPeserta 			= strtoupper($_GET['namaPeserta']);
    $nisn 					= strtoupper($_GET['nisn']);
    $asalSekolah 			= strtoupper($_GET['asalSekolah']);
    $tempatLahir			= strtoupper($_GET['tempatLahir']);
    $tanggalLahir			= strtoupper($_GET['tanggalLahir']);
    $bulanLahir		 		= strtoupper($_GET['bulanLahir']);
    $tahunLahir				= strtoupper($_GET['tahunLahir']);
    $alamat					= strtoupper($_GET['alamat']);
    $kecamatan				= strtoupper($_GET['kecamatan']);
    $kabupaten				= strtoupper($_GET['kabupaten']);
    $umur 					= strtoupper($_GET['umur']);
    $agama 					= strtoupper($_GET['agama']);
    $gender 				= strtoupper($_GET['gender']);


    $namaAyah      	= $_GET['namaAyah'];
    $pekerjaanAyah 	= $_GET['pekerjaanAyah'];
    $namaIbu 			  = $_GET['namaIbu'];
    $pekerjaanIbu 	= $_GET['pekerjaanIbu'];
    $alamatOrtu			= $_GET['alamatOrtu'];
    $kecOrtu	      = $_GET['kecamatanOrtu'];
    $kabOrtu	      = $_GET['kabupatenOrtu'];
    $telp1 					= $_GET['telp1'];
    $wa 					= $_GET['wa'];

    $kelas4smt1 	= $_GET['kelas4smt1'];
    $kelas4smt2 	= $_GET['kelas4smt2'];
    $kelas5smt1 	= $_GET['kelas5smt1'];
    $kelas5smt2 	= $_GET['kelas5smt2'];
    $kelas6smt1 	= $_GET['kelas6smt1'];
    $rataRata			= $_GET['rataRata'];

    $tanggal       = $_GET['tgl'];
    $noPendaftaran = $_GET['nomorPendaftaran'];
    $noPendaftar = $_GET['noPendaftar'];

    //die( $programPertama."". $programKedua ."". $kabupatenOrtu);


    $query = "INSERT INTO tb_siswa (

      id, program_pertama, program_kedua, nama_peserta, nisn, asal_sekolah, tempat_lahir, tanggal_lahir, bulan_lahir, tahun_lahir, alamat, kecamatan, kabupaten, jenis_kelamin, umur, agama,
      nama_ayah, pekerjaan_ayah, nama_ibu, pekerjaan_ibu, alamat_rumah_ortu, kecamatan_ortu,kabupaten_ortu, telp1, wa, nilai_kelas_4_smt_1, nilai_kelas_4_smt_2, nilai_kelas_5_smt_1,
      nilai_kelas_5_smt_2, nilai_kelas_6_smt_1, rata_rata_final, tanggal_daftar, nomor_pendaftaran, kode_pendaftar

     ) VALUES(

      '','$programPertama','$programKedua', '$namaPeserta', '$nisn', '$asalSekolah', '$tempatLahir','$tanggalLahir','$bulanLahir','$tahunLahir', '$alamat','$kecamatan','$kabupaten','$gender', '$umur', '$agama',
      '$namaAyah','$pekerjaanAyah','$namaIbu','$pekerjaanIbu','$alamatOrtu','$kecOrtu','$kabOrtu','$telp1','$wa','$kelas4smt1','$kelas4smt2','$kelas5smt1','$kelas5smt2','$kelas6smt1','$rataRata',
      '$tanggal', '$noPendaftaran', '$noPendaftar'


    )";

    $insert = mysqli_query($conn, $query) or die (mysqli_error($conn));

    if ($insert) {
      echo "<script>alert('Selamat, anda berhasil mendaftar, Silahkan download dan cetak Form pendaftaran ini');</script>";
	  echo "<script>window.location.href='../admin/functions/report.php?nisn=$nisn';</script>";
	  
    }else {
      echo "<script>alert('Maaf, anda gagal mendaftar. mungkin ada kesalahan');</script>";
    }

  }




?>
