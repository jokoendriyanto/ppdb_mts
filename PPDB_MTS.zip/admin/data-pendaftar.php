<?php
  include 'include/koneksi.php';
  include 'include/header.php';
?>


<main class="app-content">
  <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"></i> Data Pendaftar</h1>
      <p>Anda bisa</p>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item">Tables</li>
      <li class="breadcrumb-item active"><a href="#">Data Table</a></li>
    </ul>
  </div>
  <div class="row">



    <div class="col-md-6">
      <a href="functions/data-pendaftar-tambah.php" class="btn btn-info"> Daftarkan Siswa </a>

      <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
        <button class="btn btn-primary" type="button" disabled>Export Excel</button>
        <div class="btn-group" role="group">
          <button class="btn btn-primary dropdown-toggle" id="btnGroupDrop1" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
          <div class="dropdown-menu dropdown-menu-right">
            <a class="dropdown-item" href="functions/cetak-pendaftar.php">Export data pendaftar</a>
            <a class="dropdown-item" href="functions/cetak-nilai.php">Export data nilai</a>
          </div>
        </div>
      </div>

      <button type="submit" class="btn btn-success" onclick="window.location.reload()"> <i class="fa fa-refresh fa-lg"></i> Refresh </button>

    </div>

    <div class="col-md-12">

      <br>
      <div class="tile">
        <div class="tile-body">
          <table class="table table-hover table-bordered" id="sampleTable">
            <thead>
              <tr>
                <th>No.</th>
                <th>Nama</th>
                <th>Id Ujian Online</th>
                <th>Asal Sekolah</th>
                                <th>Pilihan</th>
              </tr>
            </thead>
            <form action="" method="post">
              <tbody>

                <?php
                  $no    = 1;
                  $query = mysqli_query($conn, "SELECT * FROM tb_siswa ORDER BY id DESC");
                  while ($data = mysqli_fetch_array($query)) {
                ?>

                <tr>
                  <td><?php echo $no++; ?></td>
                  <td><?php echo $data['nama_peserta']; ?></td>
                  <td>USR<?php echo $data['id']; ?></td>
                  <td><?php echo $data['asal_sekolah']; ?></td>
                                    <td style="width:230px;">
                    <a href="functions/data-pendaftar-lihat.php?id=<?php echo $data['id']; ?>" class="btn btn-success btn-sm">Lihat</a>
                    <a href="functions/data-pendaftar-edit.php?id=<?php echo $data['id']; ?>" class="btn btn-info btn-sm">Edit</a>
                    <a href="functions/data-pendaftar-hapus.php?id=<?php echo $data['id']; ?>" class="btn btn-danger btn-sm">Hapus</a>

                    <div class="dropdown pull-right">
                      <button class="btn btn-warning btn-sm dropdown-toggle" type="button" data-toggle="dropdown"> Cetak <span class="caret"></span></button>

                      <ul class="dropdown-menu" style="padding:10px;">
                        <li><a target="_blank" href="functions/cetak-kartu.php?id=<?php echo $data['id']; ?>&user_id=<?php echo $data['id']; ?>">Kartu Pendaftaran</a></li>
                        <li><a target="_blank" href="functions/cetak-form.php?id=<?php echo $data['id']; ?>&user_id=<?php echo $data['id']; ?>" >Form Pendaftaran</a></li>
                      </ul>
                    </div>

                  </td>
                </tr>

                <?php } ?>

              </tbody>
            </form>

          </table>
        </div>
      </div>
    </div>
  </div>
</main>


<?php
  include 'include/footer.php';
?>
