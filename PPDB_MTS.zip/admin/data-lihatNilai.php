<?php
  include 'include/koneksi.php';
  include 'include/header.php';
  include 'functions/functions.php';
?>

<style>
#country-list{ width: 310px; float:left; position: relative; margin-top: 5px; padding: 0;}
#country-list li:hover{cursor: pointer;}
.list-nama{height: 50px;}
</style>

<main class="app-content">
  <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"></i> Tambah Pendaftar</h1>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item">Tables</li>
      <li class="breadcrumb-item active"><a href="#">Data Table</a></li>
    </ul>
  </div>


  <form class="form-horizontal" method="post" action="">
  <div class="row">


    <div class="col-md-12">
      <div class="tile">
        <h3 class="tile-title"> Input Nilai Tes Tulis </h3>
        <div class="tile-body"> <br>
          <div class="table-responsive">
            <table class="table table-hover table-bordered" id="sampleTable">
              <thead>

                <tr>
                  <th>No.</th>
                  <th>Nama</th>
                  <th>no Pendaftaran</th>
                  <th>Nilai Tes</th>
                  <th>Nilai Makhraj</th>
                  <th>Nilai Kelancaran</th>
                  <th>Nilai Tajwid</th>
                  <th>Nilai Hafalan</th>

                  <th>Rata rata</th>
                  <th>Aksi</th>

                </tr>
              </thead>
              <form action="" method="post">
                <tbody>

                  <?php
                    $no    = 1;
                    $query = mysqli_query($conn, "SELECT * FROM tb_nilai ORDER BY id DESC");
                    while ($data = mysqli_fetch_array($query)) {
                  ?>

                  <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo $data['nama_peserta']; ?></td>
                    <td><?php echo $data['no_pendaftaran']; ?></td>
                    <td><?php echo $data['nilai_tes']; ?></td>
                    <td><?php echo $data['nilai_makhraj']; ?></td>
                    <td><?php echo $data['nilai_kelancaran']; ?></td>
                    <td><?php echo $data['nilai_tajwid']; ?></td>
                    <td><?php echo $data['nilai_hafalan']; ?></td>
                    <td><?php echo $data['rata_rata'];; ?></td>
                    <td style="width:230px;">
                      <a href="functions/data-nilai-edit.php?id=<?php echo $data['id']; ?>" class="btn btn-info btn-sm">Edit</a>
                      <a href="functions/data-nilai-hapus.php?id=<?php echo $data['id']; ?>" class="btn btn-danger btn-sm">Hapus</a>
                    </td>
                  </tr>

                  <?php } ?>

                </tbody>
              </form>

            </table>
          </div>
        </div>
      </div>
    </div>




    <div class="col-md-12">
      <input type="submit" name="simpan" value="Simpan" class="btn btn-info" id="simpan" style="width:100%;">
    </div>


  </form>



  </div>

</main>




<?php
  include 'include/footer.php';
?>

<script>
$(document).ready(function(){

	$("#search-box").keyup(function(){

		$.ajax({
		type: "POST",
		url: "functions/data-nilai-fetch.php",
		data:'keyword='+$(this).val(),
		beforeSend: function(){
			$("#search-box").css("background","#FFF url(LoaderIcon.gif) no-repeat 165px");
		},
		success: function(data){
			$("#suggesstion-box").show();
			$("#suggesstion-box").html(data);
		}
		});

	});


  nomor();
  function nomor(){
    $("#load").click(function(){

      var key = $("#search-box").val();
      $.ajax({
          url    : "functions/functions.php",
          method : "post",
          data   : {DataUser:1, keyword:key},
          success : function (data) {
            $("#inputkan").html(data);
          }
        })
    })

  }

  inputNilai();
  function inputNilai(){
    $("#simpan").click(function(){

      var nama        = $("#search-box").val();
      var no          = $("#noPendaftaran").val();
      var sekolah     = $("#asalSekolah").val();
      var nilai_tes   = $("#tesTulis").val();

      var nilai_makhraj     = $("#makhraj").val();
      var nilai_tajwid      = $("#tajwid").val();
      var nilai_kelancaran  = $("#kelancaran").val();
      var nilai_sikap       = $("#sikap").val();

      var sem1 = $("#sem1").val();
      var sem2 = $("#sem2").val();
      var sem3 = $("#sem3").val();
      var sem4 = $("#sem4").val();
      var sem5 = $("#sem5").val();

      $.ajax({
          url    : "functions/functions.php",
          method : "post",
          data   : {
                    InputNilai:1,
                    nama:nama,
                    no:no,
                    sekolah:sekolah,
                    nilai_tes:nilai_tes,
                    nilai_makhraj:nilai_makhraj,
                    nilai_tajwid:nilai_tajwid,
                    nilai_kelancaran:nilai_kelancaran,
                    nilai_sikap:nilai_sikap,
                    sem1 : sem1,
                    sem2 : sem2,
                    sem3 : sem3,
                    sem4 : sem4,
                    sem5 : sem5

                  },
          success : function (data) {
            alert(data);
          }
        })

    })
  }




});


function pilihNama(nama) {
  $("#search-box").val(nama);
  $("#suggesstion-box").hide();
}







</script>
