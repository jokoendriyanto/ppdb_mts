<?php
  include 'include/koneksi.php';
  include 'include/header.php';
  session_start();

  if (empty($_SESSION['user'])) {
    echo "<script> window.location.href='login.php'; </script>";
  }

?>

    <main class="app-content">
      <div class="app-sidebar__overlay" data-toggle="sidebar"></div>

      <?php
      	$query = mysqli_query($conn, "SELECT count(nama_peserta) as 'jumlah' FROM tb_siswa ");
      	$hasil = mysqli_fetch_array($query);
      	$jml   = $hasil['jumlah'];
      ?>

      <?php
      	$query = mysqli_query($conn, "SELECT count(nama_peserta) as 'input' FROM tb_nilai ");
      	$hasil = mysqli_fetch_array($query);
      	$sdhinput   = $hasil['input'];
      ?>



      <div class="row">

        <div class="col-md-12">
          <div class="alert alert-dismissible alert-success" style="background-color:white; padding:20px;">
            <strong>Assalamu'alaikum <?php echo $_SESSION['nama']; ?> !</strong>  <div id="quote"> </div>       <button class="close" type="button" data-dismiss="alert">×</button>
          </div>
        </div>

        <div class="col-md-6">
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-users fa-3x"></i>
            <div class="info">
              <h4>Jumlah Pendaftar</h4>
              <p><b><?php echo $jml; ?></b></p>
            </div>
          </div>
        </div>


        <div class="col-md-6">
          <div class="widget-small info coloured-icon"><i class="icon fa fa-files-o fa-3x"></i>
            <div class="info">
              <h4>Sudah input nilai</h4>
              <p><b><?php echo $sdhinput; ?></b></p>
            </div>
          </div>
        </div>
      </div>

    <canvas id="myChart"></canvas>

      <!-- <div class="row">
        <div class="col-md-6">
          <div class="tile">
            <h3 class="tile-title">Monthly Sales</h3>
            <div class="embed-responsive embed-responsive-16by9">
              <canvas class="embed-responsive-item" id="lineChartDemo"></canvas>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="tile">
            <h3 class="tile-title">Target Pencapaian</h3>
            <div class="embed-responsive embed-responsive-16by9">
              <canvas class="embed-responsive-item" id="pieChartDemo"></canvas>
            </div>
          </div>
        </div>
      </div> -->


    <!-- <p><a href="https://github.com/pratikborsadiya/vali-admin">Vali</a> admin template  </p> -->

    </main>




<?php
  include 'include/footer.php';
?>

<script>
  var pesan = [
    "Selamat Datang",
    "Selamat Bekerja",
    "Jangan Lupa Bahagia",
    "Awali semua dengan bismillah",
    "Sudah sholat ?",
    "Semangat dalam bekerja"
  ], pesanku = pesan[Math.floor(Math.random() * pesan.length)];

  $("#quote").append(pesanku);

</script>

<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.3.0/Chart.bundle.js"> </script> -->

<script src="assets/js/chart.min.js"> </script>

<?php
$koneksi     = mysqli_connect("localhost", "root", "", "db_ppdb");
$bulan       = mysqli_query($koneksi, "SELECT program_pertama FROM tb_siswa order by id asc");
$penghasilan = mysqli_query($koneksi, "SELECT hasil_penjualan FROM penjualan  order by id asc");
?>

<script>
            var ctx = document.getElementById("myChart");
            var myChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: [<?php while ($b = mysqli_fetch_array($bulan)) { echo '"' . $b['program_pertama'] . '",';}?>],
                    datasets: [{
                            label: '# of Votes',
                            data: [<?php while ($p = mysqli_fetch_array($penghasilan)) { echo '"' . $p['hasil_penjualan'] . '",';}?>],
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)',
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)'
                            ],
                            borderColor: [
                                'rgba(255,99,132,1)',
                                'rgba(54, 162, 235, 1)',
                                'rgba(255, 206, 86, 1)',
                                'rgba(75, 192, 192, 1)',
                                'rgba(153, 102, 255, 1)',
                                'rgba(255, 159, 64, 1)',
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(255, 206, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(255, 159, 64, 0.2)'
                            ],
                            borderWidth: 1
                        }]
                },
                options: {
                    scales: {
                        yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                    }
                }
            });
        </script>
