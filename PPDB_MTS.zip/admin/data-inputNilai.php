<?php
  include 'include/koneksi.php';
  include 'include/header.php';
  include 'functions/functions.php';
?>

<style>
#country-list{ width: 310px; float:left; position: relative; margin-top: 5px; padding: 0;}
#country-list li:hover{cursor: pointer;}
.list-nama{height: 50px;}
</style>

<main class="app-content">
  <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"></i> Tambah Pendaftar</h1>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item">Tables</li>
      <li class="breadcrumb-item active"><a href="#">Data Table</a></li>
    </ul>
  </div>


  <form class="form-horizontal" method="post" action="">
  <div class="row">


    <div class="col-md-6">
      <div class="tile">
        <h3 class="tile-title"> Cari Siswa  </h3>
        <div class="tile-body"> <br>


            <div class="form-group row">
              <label class="control-label col-md-3">Nama Peserta</label>
              <div class="col-md-8">
                <div class="frmSearch">
                <div class="input-group">
                  <input type="text" id="search-box" placeholder="Nama Peserta" autocomplete="off" class="form-control" />
                  <span class="input-group-btn">
                      <button class="btn btn-info" id="load" type="button"><span class="fa fa-caret-square-o-down"></span></button>
                  </span>
                </div>
                <div id="suggesstion-box"></div>
                </div>
              </div>
            </div> <br>

            <div id="inputkan">

            </div>


        </div>
      </div>
    </div>


    <div class="col-md-6">
      <div class="tile">
        <h3 class="tile-title"> Input Nilai Tes </h3>
        <div class="tile-body"> <br>

          <div class="form-group row">
            <label class="control-label col-md-4">Nilai Tes</label>
            <div class="col-md-8">
              <input class="form-control col-md-8" type="text" name="tesTulis" value="" id="tesTulis" required>
            </div>
          </div>

          <div class="form-group row">
            <label class="control-label col-md-4">Nilai Makhraj</label>
            <div class="col-md-8">
              <input class="form-control col-md-8" type="text" name="makhraj" id="makhraj" value="" required>
            </div>
          </div>
          <div class="form-group row">
            <label class="control-label col-md-4">Nilai Tajwid</label>
            <div class="col-md-8">
              <input class="form-control col-md-8" type="text" name="tajwid" id="tajwid" value="" required>
            </div>
          </div>
          <div class="form-group row">
            <label class="control-label col-md-4">Nilai Kelancaran</label>
            <div class="col-md-8">
              <input class="form-control col-md-8" type="text" name="kelancaran" id="kelancaran" value="" required>
            </div>
          </div>
          <div class="form-group row">
            <label class="control-label col-md-4">Nilai Jumlah Hafalan</label>
            <div class="col-md-8">
              <input class="form-control col-md-8" type="text" name="hafalan" id="hafalan" value="" required>
            </div>
          </div>

          <hr>




        </div>
      </div>
    </div>



    <div class="col-md-12">
      <input type="submit" name="simpan" value="Simpan" class="btn btn-info" id="simpan" style="width:100%;">
    </div>


  </form>



  </div>

</main>




<?php
  include 'include/footer.php';
?>

<script>
$(document).ready(function(){


  $('#DiTerima').hide();
  $('#terima').on('change', function(){

    var value = $(this).val();
    if (value == "Di Terima") {
      $('#DiTerima').show();
    } else {
      $('#DiTerima').hide();
    }

  })

	$("#search-box").keyup(function(){

		$.ajax({
		type: "POST",
		url: "functions/data-nilai-fetch.php",
		data:'keyword='+$(this).val(),
		beforeSend: function(){
			$("#search-box").css("background","#FFF url(LoaderIcon.gif) no-repeat 165px");
		},
		success: function(data){
			$("#suggesstion-box").show();
			$("#suggesstion-box").html(data);
		}
		});

	});


  nomor();
  function nomor(){
    $("#load").click(function(){

      var key = $("#search-box").val();
      $.ajax({
          url    : "functions/functions.php",
          method : "post",
          data   : {DataUser:1, keyword:key},
          success : function (data) {
            $("#inputkan").html(data);
          }
        })
    })

  }

  inputNilai();
  function inputNilai(){
    $("#simpan").click(function(){

      var nama        = $("#search-box").val();
      var idku        = $("#idku").val();
      var no          = $("#noPendaftaran").val();
      var tgl_daftar  = $("#tgl").val();
      var sekolah     = $("#asalSekolah").val();
      var prog1       = $("#prog1").val();
      var prog2       = $("#prog2").val();
      var nilai_tes   = $("#tesTulis").val();

      var sem1 = $("#sem1").val();
      var sem2 = $("#sem2").val();
      var sem3 = $("#sem3").val();
      var sem4 = $("#sem4").val();
      var sem5 = $("#sem5").val();
      var rata = $("#rata").val();

      var nilai_makhraj     = $("#makhraj").val();
      var nilai_tajwid      = $("#tajwid").val();
      var nilai_kelancaran  = $("#kelancaran").val();
      var nilai_hafalan       = $("#hafalan").val();

      if (nilai_makhraj == "") {
        alert("Data tidak boleh kosong");
      } else if (nilai_tajwid == "") {
        alert("Data tidak boleh kosong");
      } else if (nilai_kelancaran == "") {
        alert("Data tidak boleh kosong");
      } else if (nilai_hafalan == "") {
        alert("Data tidak boleh kosong");
      } else {

        $.ajax({
            url    : "functions/functions.php",
            method : "post",
            data   : {
                      InputNilai:1,
                      nama:nama,
                      idku:idku,
                      no:no,
                      tgl_daftar : tgl_daftar,
                      sekolah:sekolah,
                      prog1 : prog1,
                      prog2 : prog2,
                      nilai_tes:nilai_tes,
                      nilai_makhraj:nilai_makhraj,
                      nilai_tajwid:nilai_tajwid,
                      nilai_kelancaran:nilai_kelancaran,
                      nilai_hafalan:nilai_hafalan,
                      sem1 : sem1,
                      sem2 : sem2,
                      sem3 : sem3,
                      sem4 : sem4,
                      sem5 : sem5,
                      rata : rata
                    },
            success : function (data) {
              if (data = "Bisa") {
                alert("Anda berasil memasukkan nilai");
              } else {
                alert("Ada kesalahan saat memasukkan nilai");
              }
            }
          })


      }

      // get value dari select
      // var cek_status        = $("#terima").find("option:selected").text();
      // var status            = $("#terima").val();
      //
      // var cek_program       = $("#program").find("option:selected").text();
      // var program           = $("#program").val();


    })
  }




});


function pilihNama(nama) {
  $("#search-box").val(nama);
  $("#suggesstion-box").hide();
}







</script>
