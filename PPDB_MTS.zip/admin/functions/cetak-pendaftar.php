<?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=daftar-pendaftar.xls");
include '../include/koneksi.php';
?>

<table class="table table-striped">
      <thead>
          <tr>
              <th>No</th>
              <th>Nama Pendaftar</th>
              <th>Program Pertama</th>
              <th>Program Kedua</th>
              <th>NISN</th>
              <th>Asal Sekolah</th>
              <th>Tempat lahir</th>
              <th>Tanggal lahir</th>
              <th>Bulan Lahir</th>
              <th>Tahun Lahir</th>
              <th>Alamat</th>
              <th>Kecamatan</th>
              <th>Kabupaten</th>
              <th>Jenis Kelamin</th>
              <th>Umur</th>
              <th>Agama</th>
              <th>Nama Ayah</th>
              <th>Pekerjaan Ayah</th>
              <th>Nama Ibu</th>
              <th>Pekerjaan Ibu</th>
              <th>Alamat sumah ortu</th>
              <th>Kecamatan Ortu</th>
              <th>Kabupaten Ortu</th>
              <th>No. telp 1</th>
              <th>No. WA</th>
              <th>Nomor Pendaftaran</th>
          </tr>
      </thead>
      <tbody>
        <?php
          $no    = 1;
          $query = mysqli_query($conn, "SELECT * FROM tb_siswa");
          while ($data = mysqli_fetch_array($query)) {
        ?>

        <tr>
            <td><?php echo $no++;; ?></td>
            <td><?php echo $data['nama_peserta']; ?></td>
            <td><?php echo $data['program_pertama']; ?></td>
            <td><?php echo $data['program_kedua']; ?></td>
            <td><?php echo $data['nisn']; ?></td>
            <td><?php echo $data['asal_sekolah']; ?></td>
            <td><?php echo $data['tempat_lahir']; ?></td>
            <td><?php echo $data['tanggal_lahir']; ?></td>
            <td><?php echo $data['bulan_lahir']; ?></td>
            <td><?php echo $data['tahun_lahir'];; ?></td>
            <td><?php echo $data['alamat']; ?></td>
            <td><?php echo $data['kecamatan']; ?></td>
            <td><?php echo $data['kabupaten']; ?></td>
            <td><?php echo $data['jenis_kelamin']; ?></td>
            <td><?php echo $data['umur']; ?></td>
            <td><?php echo $data['agama']; ?></td>
            <td><?php echo $data['nama_ayah']; ?></td>
            <td><?php echo $data['pekerjaan_ayah']; ?></td>
            <td><?php echo $data['nama_ibu']; ?></td>
            <td><?php echo $data['pekerjaan_ibu']; ?></td>
            <td><?php echo $data['alamat_rumah_ortu']; ?></td>
            <td><?php echo $data['kecamatan_ortu']; ?></td>
            <td><?php echo $data['kabupaten_ortu']; ?></td>
            <td><?php echo $data['telp1']; ?></td>
            <td><?php echo $data['wa']; ?></td>
            <td><?php echo $data['nomor_pendaftaran']; ?></td>
        </tr>

        <?php } ?>
      </tbody>

</table>
