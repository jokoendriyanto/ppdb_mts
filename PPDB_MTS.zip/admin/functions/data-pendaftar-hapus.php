<?php
  include '../include/koneksi.php';

  $id = $_GET['id'];

  $query = mysqli_query($conn, "DELETE from tb_siswa WHERE id='$id'  ") or die(mysqli_error($conn)) ;

  if ($query) {
    echo "<script> alert('Data berhasil di hapus'); window.location.href='../data-pendaftar.php'; </script>";
  } else {
    echo "<script> alert('Data gagal di hapus'); </script>";
  }

?>
