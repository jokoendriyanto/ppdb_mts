<?php
include '../include/koneksi.php';


function tambahUser(){
    include '../include/koneksi.php';

    if (isset($_POST['daftar'])) {

      $programPertama 				= $_POST['programPertama'];
      $programKedua 				  = $_POST['programKedua'];

      $namaPeserta 		= $_POST['namaPeserta'];
      $nisn 					= $_POST['nisn'];
      $asalSekolah 		= $_POST['asalSekolah'];

      $tempatLahir		= $_POST['tempatLahir'];
      $tanggalLahir		= $_POST['tanggalLahir'];
      $bulanLahir		  = $_POST['bulanLahir'];
      $tahunLahir			= $_POST['tahunLahir'];

      $alamat					= $_POST['alamat'];
      $kecamatan			= $_POST['kecamatan'];
      $kabupaten			= $_POST['kabupaten'];
      $umur 					= $_POST['umur'];
      $agama 					= $_POST['agama'];
      $gender 				= $_POST['gender'];


      $namaAyah      	= $_POST['namaAyah'];
      $pekerjaanAyah 	= $_POST['pekerjaanAyah'];
      $namaIbu 			  = $_POST['namaIbu'];
      $pekerjaanIbu 	= $_POST['pekerjaanIbu'];
      $alamatOrtu			= $_POST['alamatOrtu'];
      $kecOrtu	      = $_POST['kecamatanOrtu'];
      $kabOrtu	      = $_POST['kabupatenOrtu'];
      $telp1 					= $_POST['telp1'];
      $wa					= $_POST['wa'];

      $kelas4smt1 	= $_POST['kelas4smt1'];
      $kelas4smt2 	= $_POST['kelas4smt2'];
      $kelas5smt1 	= $_POST['kelas5smt1'];
      $kelas5smt2 	= $_POST['kelas5smt2'];
      $kelas6smt1 	= $_POST['kelas6smt1'];
      $rataRata			= $_POST['rataRata'];

      $tanggal       = $_POST['tgl'];
      $noPendaftaran = $_POST['noPendaftaran'];
      $noPendaftar   = $_POST['noPendaftar'];

      //die( $program."".$namaPeserta."". $nisn."". $asalSekolah."". $ttl."". $alamat."". $umur."". $agama."". $gender );

      $query = "INSERT INTO tb_siswa (

        id, program_pertama, program_kedua, nama_peserta, nisn, asal_sekolah, tempat_lahir, tanggal_lahir, bulan_lahir, tahun_lahir, alamat, kecamatan, kabupaten, jenis_kelamin, umur, agama,
        nama_ayah, pekerjaan_ayah, nama_ibu, pekerjaan_ibu, alamat_rumah_ortu, kecamatan_ortu,kabupaten_ortu, telp1, wa, nilai_kelas_4_smt_1, nilai_kelas_4_smt_2, nilai_kelas_5_smt_1,
        nilai_kelas_5_smt_2, nilai_kelas_6_smt_1, rata_rata_final, tanggal_daftar, nomor_pendaftaran, kode_pendaftar

       ) VALUES(

        '','$programPertama','$programKedua', '$namaPeserta', '$nisn', '$asalSekolah', '$tempatLahir','$tanggalLahir','$bulanLahir','$tahunLahir', '$alamat','$kecamatan','$kabupaten','$gender', '$umur', '$agama',
        '$namaAyah','$pekerjaanAyah','$namaIbu','$pekerjaanIbu','$alamatOrtu','$kecOrtu','$kabOrtu','$telp1','$wa','$kelas4smt1','$kelas4smt2','$kelas5smt1','$kelas5smt2','$kelas6smt1','$rataRata',
        '$tanggal','$noPendaftaran', '$noPendaftar'


      )";

      $insert = mysqli_query($conn, $query) or die (mysqli_error($conn));

      if ($insert) {
        echo "<script>alert('Selamat, anda berhasil mendaftar'); </script>";
      }else {
        echo "<script>alert('Maaf, anda gagal mendaftar. mungkin ada kesalahan');</script>";
      }







    }

}

function editUser(){

  include '../include/koneksi.php';

  if (isset($_POST['update'])) {

    $idnya          = $_POST['idnya'];

    $programPertama = $_POST['programPertama'];
    $programKedua 	= $_POST['programKedua'];

    $namaPeserta 		= $_POST['namaPeserta'];
    $nisn 					= $_POST['nisn'];
    $asalSekolah 		= $_POST['asalSekolah'];

    $tempatLahir		= $_POST['tempatLahir'];
    $tanggalLahir		= $_POST['tanggalLahir'];
    $bulanLahir		= $_POST['bulanLahir'];
    $tahunLahir			= $_POST['tahunLahir'];

    $alamat					= $_POST['alamat'];
    $kecamatan			= $_POST['kecamatan'];
    $kabupaten			= $_POST['kabupaten'];
    $umur 					= $_POST['umur'];
    $agama 					= $_POST['agama'];
    $gender 				= $_POST['gender'];


    $namaAyah      	= $_POST['namaAyah'];
    $pekerjaanAyah 	= $_POST['pekerjaanAyah'];
    $namaIbu 			  = $_POST['namaIbu'];
    $pekerjaanIbu 	= $_POST['pekerjaanIbu'];
    $alamatOrtu			= $_POST['alamatOrtu'];
    $kecOrtu	      = $_POST['kecamatanOrtu'];
    $kabOrtu	      = $_POST['kabupatenOrtu'];
    $telp1 					= $_POST['telp1'];
    $wa 					= $_POST['wa'];

    $kelas4smt1 	= $_POST['kelas4smt1'];
    $kelas4smt2 	= $_POST['kelas4smt2'];
    $kelas5smt1 	= $_POST['kelas5smt1'];
    $kelas5smt2 	= $_POST['kelas5smt2'];
    $kelas6smt1 	= $_POST['kelas6smt1'];
    $rataRata			= $_POST['rataRata'];


    $query = mysqli_query($conn, " UPDATE tb_siswa SET

      program_pertama='$programPertama', program_kedua='$programKedua', nama_peserta='$namaPeserta', nisn='$nisn', asal_sekolah='$asalSekolah', tempat_lahir='$tempatLahir', tanggal_lahir='$tanggalLahir',bulan_lahir='$bulanLahir', tahun_lahir='$tahunLahir',
      alamat='$alamat', kecamatan='$kecamatan', kabupaten='$kabupaten', umur='$umur', agama='$agama', jenis_kelamin='$gender',
      nama_ayah='$namaAyah', pekerjaan_ayah='$pekerjaanAyah', nama_ibu='$namaIbu', pekerjaan_ibu='$pekerjaanIbu', alamat_rumah_ortu='$alamatOrtu', kecamatan_ortu='$kecOrtu', kabupaten_ortu='$kabOrtu',
      telp1='$telp1', wa='$wa', nilai_kelas_4_smt_1='$kelas4smt1', nilai_kelas_4_smt_2='$kelas4smt2', nilai_kelas_5_smt_1='$kelas5smt1', nilai_kelas_5_smt_2='$kelas5smt2', nilai_kelas_6_smt_1='$kelas6smt1',
      rata_rata_final='$rataRata'

      WHERE id='$idnya';

    ") or die(mysqli_error($conn));

    if ($query) {
      echo "<script> alert('Update data berhasil '); window.location.href='../data-pendaftar.php';  </script>";
    } else {
      echo "<script> alert('Update data gagal ')  </script>";
    }


  }


}



// FUNGSI CAMPUR





  if (isset($_POST['DataUser'])) {

    $key = $_POST['keyword'];

    $query = mysqli_query($conn, "SELECT * FROM tb_siswa WHERE nama_peserta='$key' " ) or die(mysqli_error($conn));
    while ($hasil = mysqli_fetch_array($query)) {
        $nomor = $hasil['nomor_pendaftaran'];
        $sekolah = $hasil['asal_sekolah'];
        $prog1  = $hasil['program_pertama'];
        $prog2  = $hasil['program_kedua'];
        $idku  = $hasil['id'];
        $s1  = $hasil['nilai_kelas_4_smt_1'];
        $s2 = $hasil['nilai_kelas_4_smt_2'];
        $s3 = $hasil['nilai_kelas_5_smt_1'];
        $s4 = $hasil['nilai_kelas_5_smt_2'];
        $s5 = $hasil['nilai_kelas_6_smt_1'];
        $rata = $hasil['rata_rata_final'];
        $tgl_daftar = $hasil['tanggal_daftar'];
        $prog1 = $hasil['program_pertama'];
        $prog2 = $hasil['program_kedua'];
    ?>

    <div class="form-group row">
      <input class="form-control col-md-8" type="hidden" id="sem1" name="sem1" value="<?php echo $s1; ?>">
      <input class="form-control col-md-8" type="hidden" id="sem2" name="sem2" value="<?php echo $s2; ?>">
      <input class="form-control col-md-8" type="hidden" id="sem3" name="sem3" value="<?php echo $s3; ?>">
      <input class="form-control col-md-8" type="hidden" id="sem4" name="sem4" value="<?php echo $s4; ?>">
      <input class="form-control col-md-8" type="hidden" id="sem5" name="sem5" value="<?php echo $s5; ?>">
      <input class="form-control col-md-8" type="hidden" id="rata" name="rata" value="<?php echo $rata; ?>">

    </div>

    <input type="hidden" id="idku" name="idku" value="<?php echo $idku; ?>">
    <input type="hidden" id="tgl" name="tgl" value="<?php echo $tgl_daftar; ?>">
    <input type="hidden" id="prog1" name="prog1" value="<?php echo $prog1; ?>">
    <input type="hidden" id="prog2" name="prog2" value="<?php echo $prog2; ?>">

    <div class="form-group row">
      <label class="control-label col-md-3">ID Ujian Online</label>
      <div class="col-md-8">
        <input class="form-control col-md-8" type="text" id="id" name="id" value="USR<?php echo $idku; ?>" disabled>
      </div>
    </div>
    <div class="form-group row">
      <label class="control-label col-md-3">No Pendaftaran</label>
      <div class="col-md-8">
        <input class="form-control col-md-8" type="text" id="noPendaftaran" name="noPendaftaran" value="<?php echo $nomor; ?>" disabled>
      </div>
    </div>
    <div class="form-group row">
      <label class="control-label col-md-3">Asal Sekolah</label>
      <div class="col-md-8">
        <input class="form-control col-md-8" type="text" id="asalSekolah" name="asalSekolah" value="<?php echo $sekolah; ?>" disabled>
      </div>
    </div>
    <div class="form-group row">
      <label class="control-label col-md-3">Pilihan Pertama</label>
      <div class="col-md-8">
        <input class="form-control col-md-8" type="text" id="asalSekolah" name="asalSekolah" value="<?php echo $prog1; ?>" disabled>
      </div>
    </div>
    <div class="form-group row">
      <label class="control-label col-md-3">Pilihan Kedua</label>
      <div class="col-md-8">
        <input class="form-control col-md-8" type="text" id="asalSekolah" name="asalSekolah" value="<?php echo $prog2; ?>" disabled>
      </div>
    </div>



<?php
  } }

if (isset($_POST['InputNilai'])) {
  $nama      = $_POST['nama'];
  $no        = $_POST['no'];
  $sekolah   = $_POST['sekolah'];
  $nilai_tes = $_POST['nilai_tes'];
  $idku      = $_POST['idku'];
  $tgl_daftar = $_POST['tgl_daftar'];
  $prog1 = $_POST['prog1'];
  $prog2 = $_POST['prog2'];

  $nilai_makhraj    = $_POST['nilai_makhraj'];
  $nilai_tajwid     = $_POST['nilai_tajwid'];
  $nilai_kelancaran = $_POST['nilai_kelancaran'];
  $nilai_hafalan      = $_POST['nilai_hafalan'];
  // $status           = $_POST['status'];
  // $program          = $_POST['program'];


  $smt1 = $_POST['sem1'];
  $smt2 = $_POST['sem2'];
  $smt3 = $_POST['sem3'];
  $smt4 = $_POST['sem4'];
  $smt5 = $_POST['sem5'];
  $rata = $_POST['rata'];


  $query = mysqli_query($conn, "INSERT INTO tb_nilai ( nama_peserta, id_peserta, no_pendaftaran, tanggal_daftar, asal_sekolah, program_pertama , program_kedua ,nilai_tes, nilai_makhraj, nilai_kelancaran, nilai_hafalan, nilai_tajwid, nilai_kelas_4_smt_1, nilai_kelas_4_smt_2, nilai_kelas_5_smt_1, nilai_kelas_5_smt_2, nilai_kelas_6_smt_1,rata_rata) VALUES (

    '$nama','$idku','$no','$tgl_daftar','$sekolah','$prog1','$prog2','$nilai_tes','$nilai_makhraj','$nilai_kelancaran','$nilai_hafalan','$nilai_tajwid','$smt1','$smt2','$smt3','$smt4','$smt5','$rata'

    )  ") or die(mysqli_error($conn));

  if ($query) {
    echo "Bisa";
  } else {
    echo "gagal";
  }


}















?>
