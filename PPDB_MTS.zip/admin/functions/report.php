<?php
  include '../include/koneksi.php';
  session_start();
?>
<style type="text/css">
<!--
.style6 {font-size: 18px}
-->
</style>

<table width="200" border="1">
  <tr>
    <td><div align="center"><img src="../assets/img/kartu.png" width="750" height="160"></div></td>
  </tr>
  <tr>
    <td><div align="center">
      <h1>KARTU TANDA PENDAFTARAN</h1>
      <p class="style6">Dibawah ini merupakan Calon Peserta Didik Baru, MTs N 2 Sukoharjo</p>
      <p align="left">
		<table align="center">
				<?php
                  $nisn = $_GET['nisn'];
                  $query = mysqli_query($conn, "SELECT * FROM tb_siswa WHERE nisn='$nisn' ");
                  $hasil = mysqli_fetch_array($query);
                ?>
                <tbody>
                  <tr>
                    <td><span class="style6">No Pendaftaran</span> </td>
                    <td> : </td>
                    <td> <span class="style6"><?php echo $hasil['nomor_pendaftaran']; ?></span> </td>
                  </tr>
                  <tr>
                    <td><span class="style6">Nama </span></td>
                    <td> : </td>
                    <td> <span class="style6"><?php echo $hasil['nama_peserta']; ?></span> </td>
                  </tr>
                  <tr>
                    <td width="150"><span class="style6">Asal sekolah</span> </td>
                    <td  width="15"> : </td>
                    <td> <span class="style6"><?php echo $hasil['asal_sekolah']; ?></span></td>
                  </tr>

                  <tr>
                    <td><span class="style6">Tgl pendaftaran</span> </td>
                    <td> : </td>
                    <td> <span class="style6"><?php echo $hasil['tanggal_daftar']; ?></span></td>
                  </tr>
                  <tr>
                    <td><span class="style6">Prog Pertama</span> </td>
                    <td> : </td>
                    <td> <span class="style6"><?php echo $hasil['program_pertama']; ?></span></td>
                  </tr>
                  <tr>
                    <td><span class="style6">Prog Kedua </span></td>
                    <td> : </td>
                    <td> <span class="style6"><?php echo $hasil['program_kedua']; ?></span></td>
                  </tr>
                </tbody>
        </table>
      </p>
    </div></td>
  </tr>
  <tr>
    <td><div align="center"><img src="../assets/img/pengumuman2.jpg" alt="" width="627" height="288" /></div></td>
  </tr>
  <tr>
    <td><div align="center"><img src="../assets/img/panitia.jpg" alt="" width="650" height="180"></div></td>
  </tr>
</table>

<?php
$content=ob_get_clean();
require_once("html2pdf/html2pdf.class.php");
$pdf=new HTML2PDF('p', 'A4','fr','UTF-8');
$pdf->writeHTML($content);
$pdf->pdf->IncludeJS('print(TRUE)');
$pdf->output('test.pdf');
?>