<?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=cetak-nilai.xls");
include '../include/koneksi.php';
?>

<table class="table table-striped">
      <thead>
          <tr>
              <th>No</th>
              <th>Nama Pendaftar</th>
              <th>No Pendaftar</th>
              <th>Asal Sekolah</th>
              <th>Tanggal Pendaftaran</th>
              <th>Program Pertama</th>
              <th>Program Kedua</th>
              <th>Nilai Tes</th>
              <th>Nilai Makhraj</th>
              <th>Nilai Tajwid</th>
              <th>Nilai Kelancaran</th>
              <th>Nilai Hafalan</th>
              <th>Nilai kelas 4 smt1</th>
              <th>Nilai kelas 4 smt2</th>
              <th>Nilai kelas 5 smt1</th>
              <th>Nilai kelas 5 smt2</th>
              <th>Nilai kelas 6 smt1</th>
              <th>Rata-rata</th>
          </tr>
      </thead>
      <tbody>
        <?php
          $no    = 1;
          $query = mysqli_query($conn, "SELECT * FROM tb_nilai");
          while ($data = mysqli_fetch_array($query)) {
        ?>

        <tr>
            <td><?php echo $no++;; ?></td>
            <td><?php echo $data['nama_peserta']; ?></td>
            <td><?php echo $data['no_pendaftaran']; ?></td>
            <td><?php echo $data['asal_sekolah']; ?></td>
            <td><?php echo $data['tanggal_daftar']; ?></td>
            <td><?php echo $data['program_pertama']; ?></td>
            <td><?php echo $data['program_kedua']; ?></td>
            <td><?php echo $data['nilai_tes']; ?></td>
            <td><?php echo $data['nilai_makhraj']; ?></td>
            <td><?php echo $data['nilai_tajwid']; ?></td>
            <td><?php echo $data['nilai_kelancaran']; ?></td>
            <td><?php echo $data['nilai_hafalan']; ?></td>
            <td><?php echo $data['nilai_kelas_4_smt_1']; ?></td>
            <td><?php echo $data['nilai_kelas_4_smt_2']; ?></td>
            <td><?php echo $data['nilai_kelas_5_smt_1']; ?></td>
            <td><?php echo $data['nilai_kelas_5_smt_2']; ?></td>
            <td><?php echo $data['nilai_kelas_6_smt_1']; ?></td>
            <td><?php echo $data['rata_rata']; ?></td>
        </tr>

        <?php } ?>
      </tbody>

</table>
