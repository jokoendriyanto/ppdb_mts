<?php
  include '../include/koneksi.php';

  $id    = $_GET['id'];
  $query = mysqli_query($conn, "DELETE from tb_nilai WHERE id='$id' ");

  if ($query) {
    echo "<script> alert('Data berhasil di hapus'); window.location.href='../data-lihatNilai.php'; </script>";
  } else {
    echo "<script> alert('Data gagal di hapus'); </script>";
  }

?>
