<?php
  include '../include/koneksi.php';
  session_start();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <!-- Twitter meta-->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:site" content="@pratikborsadiya">
    <meta property="twitter:creator" content="@pratikborsadiya">
    <!-- Open Graph Meta-->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Vali Admin">
    <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
    <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
    <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
    <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="../assets/css/main.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Print Form Pendaftaran</title>
    <style>
      td {
        height: 30px;
        font-size: 20px;
      }
      td:hover{
        background-color: coral;
      }
    </style>
  </head>
  <body class="app sidebar-mini">
    <!-- Navbar-->

    <div class="container" style="margin-top:30px;">

        <div class="panel panel-default" style="border-radius:0px;">
          <div class="panel-heading" style="background-color:white;">
            <div class="container">
              <img style="margin:auto;" src="../assets/img/kartu.png" width="550" class="img-responsive"><input style="width:120px;" class="btn btn-info" type="submit" id="cetak" value="print">
              <!-- <div class="col-md-2" style="  padding-left:30px;">
                <img src="../assets/img/logo.jpg" class="img-responsive" width="120">
              </div>
              <div class="col-md-10">
                <p style="font-size:30px; font-weight:bold; margin-left:0; line-height:35px; "> Formulir Pendaftaran <br>  Penerimaan Peserta Didik baru</p>
                <p style="">MADRASAH TSANAWIYAH NEGERI SUKOHARJO</p>
              </div> -->
            </div>
          </div>
          <div class="panel-body">
            <div class="container">
              <!-- <h4>Dengan ini kami menyatakan bahwa yang tertera di bawah ini :</h4> -->
<h3 align="center">FORMULIR PENDAFTARAN</h3>
              <br>
              <table>
                <?php
                  $id = $_GET['id'];
                  $query = mysqli_query($conn, "SELECT * FROM tb_siswa WHERE id='$id' ");
                  $hasil = mysqli_fetch_array($query);
                ?>
                <tbody>
                  <tr>
                    <td>Nama </td>
                    <td> : </td>
                    <td> <?php echo $hasil['nama_peserta']; ?> </td>
                  </tr>
                  <tr>
                    <td width="170">NISN </td>
                    <td width="18"> : </td>
                    <td> <?php echo $hasil['nisn']; ?></td>
                  </tr>
                  <tr>
                    <td>Asal sekolah </td>
                    <td> : </td>
                    <td> <?php echo $hasil['asal_sekolah']; ?></td>
                  </tr>
                  <tr>
                    <td>Alamat </td>
                    <td> : </td>
                    <td> <?php echo $hasil['alamat']; ?></td>
                  </tr>
                  <tr>
                    <td>Pilihan Pertama </td>
                    <td> : </td>
                    <td> <?php echo $hasil['program_pertama']; ?></td>
                  </tr>
                  <tr>
                    <td>Pilihan Kedua </td>
                    <td> : </td>
                    <td> <?php echo $hasil['program_kedua']; ?></td>
                  </tr>
                  <tr>
                    <td>TTL </td>
                    <td> : </td>
                    <td> <?php echo $hasil['tempat_lahir']; ?>,  <?php echo $hasil['tanggal_lahir']; ?> <?php echo $hasil['bulan_lahir']; ?> <?php echo $hasil['tahun_lahir']; ?> </td>
                  </tr>
                  <tr>
                    <td>Jenis Kelamin </td>
                    <td> : </td>
                    <td> <?php echo $hasil['jenis_kelamin']; ?></td>
                  </tr>
                  <tr>
                    <td>Umur </td>
                    <td> : </td>
                    <td> <?php echo $hasil['umur']; ?></td>
                  </tr>
                  <tr>
                    <td>Agama </td>
                    <td> : </td>
                    <td> <?php echo $hasil['agama']; ?></td>
                  </tr>
                  <tr>
                    <td>Nama Ayah</td>
                    <td> : </td>
                    <td> <?php echo $hasil['nama_ayah']; ?></td>
                  </tr>
                  <tr>
                    <td>Pekerjaan Ayah </td>
                    <td> : </td>
                    <td> <?php echo $hasil['pekerjaan_ayah']; ?></td>
                  </tr>
                  <tr>
                    <td>Nama Ibu</td>
                    <td> : </td>
                    <td> <?php echo $hasil['nama_ibu']; ?></td>
                  </tr>
                  <tr>
                    <td>Pekerjaan Ibu </td>
                    <td> : </td>
                    <td> <?php echo $hasil['pekerjaan_ibu']; ?></td>
                  </tr>
                  <tr>
                    <td>Alamat Orang tua </td>
                    <td> : </td>
                    <td> <?php echo $hasil['alamat_rumah_ortu']; ?></td>
                  </tr>
                  <tr>
                    <td>Telp 1 </td>
                    <td> : </td>
                    <td> <?php echo $hasil['telp1']; ?></td>
                  </tr>
                  <tr>
                    <td>No WA </td>
                    <td> : </td>
                    <td> <?php echo $hasil['wa']; ?></td>
                  </tr>




                </tbody>
              </table>

              <br><br>
              <table class="table table-striped">
                <tr>
                  <th colspan="2" style="text-align:center; background-color:#3498db; color:white;  ">Kelas 4</th>
                  <th colspan="2" style="text-align:center; background-color:#3498db; color:white; ">Kelas 5</th>
                  <th colspan="2" style="text-align:center; background-color:#3498db; color:white; ">Kelas 6</th>
                  <th colspan="2" rowspan="2" style="text-align:center; background-color:#2980b9; color:white; "> Rata-rata Akhir </th>
                </tr>
                <tr>
                  <td>semester 1</td>
                  <td>semester 2</td>
                  <td>semester 1</td>
                  <td>semester 2</td>
                  <td colspan="2">semester 1</td>
                </tr>

                <tr>
                  <td><input type="text" class="form-control form-qu" value="<?php echo $hasil['nilai_kelas_4_smt_1']; ?>" disabled  ></td>
                  <td><input type="text" class="form-control form-qu" value="<?php echo $hasil['nilai_kelas_4_smt_2']; ?>" disabled ></td>

                  <td><input type="text" class="form-control form-qu" value="<?php echo $hasil['nilai_kelas_5_smt_1']; ?>" disabled ></td>
                  <td><input type="text" class="form-control form-qu" value="<?php echo $hasil['nilai_kelas_5_smt_2']; ?>" disabled ></td>

                  <td colspan="2"><input type="text" class="form-control form-qu" value="<?php echo $hasil['nilai_kelas_6_smt_1']; ?>" disabled ></td>

                  <td><input type="text" class="form-control form-qu" value="<?php echo $hasil['rata_rata_final']; ?>" disabled></td>
                </tr>

              </table>

              
            </div>
            <br><br><br>

            <table>
              <tr>
                <th style="width:480px;"></th>
                <th><h4>Mengetahui</h4></th>
                <th></th>
              </tr>
              <tr>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <td style="padding-left:90px;">Wali Siswa</td>
                <td style="width:380px;"></td>
                <td>Panitia</td>
              </tr>
              <tr>
                <td></td>
              </tr>
              <tr>
                <td></td>
              </tr>
              <tr>
                <td></td>
              </tr>
              <tr>
                <td style="padding-left:90px;"><?php echo $hasil['nama_ayah']; ?></td>
                <td style="width:380px;"></td>
                <td>-----------------</td>
              </tr>
            </table>


          



          </div>


        </div>





    </div>

    <script src="../assets/js/jquery-3.2.1.min.js"></script>
    <script src="../functions/functions.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>

    <script>

    $(document).ready(function(){

      $("#cetak").click(function(){
        $("#cetak").hide();
        window.print();
      })

    })

    // var cetak = confirm("Cetak kartu pendaftaran dan form pengumuman ?");
    //
    // if (cetak == true) {
    //   window.print();
    // } else {
    //   window.location.href="../data-pendaftar.php";
    // }
    </script>
