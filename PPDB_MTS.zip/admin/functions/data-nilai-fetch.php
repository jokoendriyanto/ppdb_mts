<?php

include '../include/koneksi.php';
require_once("dbcontroller.php");
$db_handle = new DBController();
if(!empty($_POST["keyword"])) {
$query ="SELECT * FROM tb_siswa WHERE nama_peserta like '" . $_POST["keyword"] . "%' ORDER BY id DESC";
$result = $db_handle->runQuery($query);


if(!empty($result)) {
?>
<ul id="country-list" class="list-group">
<?php
foreach($result as $nama) {
?>
<li id="list" class="list-group-item list-group-item-info list-nama" onClick="pilihNama('<?php echo $nama["nama_peserta"]; ?>');"><?php echo $nama["nama_peserta"]; ?></li>
<?php } ?>
</ul>
<?php } } ?>
