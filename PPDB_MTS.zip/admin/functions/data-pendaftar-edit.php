<?php
  include '../include/koneksi.php';
  include 'functions.php';
  error_reporting(0);
  session_start();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <!-- Twitter meta-->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:site" content="@pratikborsadiya">
    <meta property="twitter:creator" content="@pratikborsadiya">
    <!-- Open Graph Meta-->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Vali Admin">
    <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
    <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
    <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
    <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="../assets/css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="../assets/fa/css/font-awesome.min.css">
    <title>Administrator</title>
  </head>
  <body class="app sidebar-mini">
    <header class="app-header"><a class="app-header__logo" href="index.html"> Ppdb   </a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
        <li class="app-search">
          <input class="app-search__input" type="search" placeholder="Search">
          <button class="app-search__button"><i class="fa fa-search"></i></button>
        </li>
        <!--Notification Menu-->
        <!-- <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown"><i class="fa fa-bell-o fa-lg"></i></a>
          <ul class="app-notification dropdown-menu dropdown-menu-right">
            <li class="app-notification__title">You have 4 new notifications.</li>
            <div class="app-notification__content">
              <li><a class="app-notification__item" href="javascript:;"><span class="app-notification__icon"><span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x text-primary"></i><i class="fa fa-envelope fa-stack-1x fa-inverse"></i></span></span>
                  <div>
                    <p class="app-notification__message">Lisa sent you a mail</p>
                    <p class="app-notification__meta">2 min ago</p>
                  </div></a></li>
              <li><a class="app-notification__item" href="javascript:;"><span class="app-notification__icon"><span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x text-danger"></i><i class="fa fa-hdd-o fa-stack-1x fa-inverse"></i></span></span>
                  <div>
                    <p class="app-notification__message">Mail server not working</p>
                    <p class="app-notification__meta">5 min ago</p>
                  </div></a></li>
              <li><a class="app-notification__item" href="javascript:;"><span class="app-notification__icon"><span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x text-success"></i><i class="fa fa-money fa-stack-1x fa-inverse"></i></span></span>
                  <div>
                    <p class="app-notification__message">Transaction complete</p>
                    <p class="app-notification__meta">2 days ago</p>
                  </div></a></li>
              <div class="app-notification__content">
                <li><a class="app-notification__item" href="javascript:;"><span class="app-notification__icon"><span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x text-primary"></i><i class="fa fa-envelope fa-stack-1x fa-inverse"></i></span></span>
                    <div>
                      <p class="app-notification__message">Lisa sent you a mail</p>
                      <p class="app-notification__meta">2 min ago</p>
                    </div></a></li>
                <li><a class="app-notification__item" href="javascript:;"><span class="app-notification__icon"><span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x text-danger"></i><i class="fa fa-hdd-o fa-stack-1x fa-inverse"></i></span></span>
                    <div>
                      <p class="app-notification__message">Mail server not working</p>
                      <p class="app-notification__meta">5 min ago</p>
                    </div></a></li>
                <li><a class="app-notification__item" href="javascript:;"><span class="app-notification__icon"><span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x text-success"></i><i class="fa fa-money fa-stack-1x fa-inverse"></i></span></span>
                    <div>
                      <p class="app-notification__message">Transaction complete</p>
                      <p class="app-notification__meta">2 days ago</p>
                    </div></a></li>
              </div>
            </div>
            <li class="app-notification__footer"><a href="#">See all notifications.</a></li>
          </ul>
        </li> -->
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown"><i class="fa fa-user fa-lg"></i></a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
            <li><a class="dropdown-item" href="page-user.html"><i class="fa fa-cog fa-lg"></i> Settings</a></li>
            <li><a class="dropdown-item" href="page-user.html"><i class="fa fa-user fa-lg"></i> Profile</a></li>
            <li><a class="dropdown-item" href="logout.php"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </header>
    <aside class="app-sidebar">
      <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="https://s3.amazonaws.com/uifaces/faces/twitter/jsa/48.jpg" alt="User Image">
        <div>

          <?php
            $query = mysqli_query($conn, "SELECT * FROM tb_admin");
          ?>

          <p class="app-sidebar__user-name"><?php echo $_SESSION['nama']; ?></p>
          <p class="app-sidebar__user-designation">Administrator</p>
        </div>
      </div>
      <ul class="app-menu">
        <li><a class="app-menu__item active" href="../index.php"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>

        <li><a class="app-menu__item" href="../data-pendaftar.php"><i class="app-menu__icon fa fa-user-circle-o"></i><span class="app-menu__label">Data Pendaftar</span></a></li>
        <li><a class="app-menu__item" href="../data-admin.php"><i class="app-menu__icon fa fa-user"></i><span class="app-menu__label">Data Admin</span></a></li>
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-th-list"></i><span class="app-menu__label">Nilai</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="app-menu__item" href="../data-inputNilai.php"><i class="app-menu__icon fa fa-file-text-o"></i><span class="app-menu__label">Input Nilai</span></a></li>
            <li><a class="app-menu__item" href="../data-lihatNilai.php"><i class="app-menu__icon fa fa-file-text-o"></i><span class="app-menu__label">Lihat Nilai</span></a></li>
          </ul>
        </li>
      </ul>
    </aside>




<main class="app-content">
  <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"></i> Edit data Pendaftar</h1>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item">Tables</li>
      <li class="breadcrumb-item active"><a href="#">Data Table</a></li>
    </ul>
  </div>


  <form class="form-horizontal" method="post" action="">


  <div class="row">

    <?php
      $id    = $_GET['id'];
      $query = mysqli_query($conn, "SELECT * FROM tb_siswa WHERE id='$id'  ");
      while ($data = mysqli_fetch_array($query)) {
    ?>

    <div class="col-md-12">
      <div class="tile">
        <h3 class="tile-title">Edit Program</h3>
        <div class="tile-body">

        <div class="col-md-4">


          <div class="form-group">
            <?php
            $query = mysqli_query($conn, "SELECT * FROM tb_siswa WHERE id='$id'  ") or die(mysqli_error($conn));
            $hasil = mysqli_fetch_array($query);
            $prog1 = $hasil['program_pertama'];
            $prog2 = $hasil['program_kedua'];
            ?>
            <label> Pilihan Pertama anda : <b><?php echo $prog1; ?></b> </label>
            <select class="form-control" name="programPertama">
              <option value="Program Khusus ">Program Khusus (PK)</option>
              <option value="Program Boarding School ">Program Boarding School (Tahfidzul Qur'an)</option>
              <option value="Program Peminatan">Program Peminatan (Full Day)</option>
              <option value="Program Reguler">Program Reguler </option>
            </select>

          </div>
        </div>

        <div class="col-md-4">
          <div class="form-group">
            <label> Pilihan Kedua anda : <b><?php echo $prog2; ?></b> </label>
            <select class="form-control" name="programKedua">
              <option value="Program Khusus ">Program Khusus (PK)</option>
              <option value="Program Boarding School ">Program Boarding School (Tahfidzul Qur'an)</option>
              <option value="Program Peminatan">Program Peminatan (Full Day)</option>
              <option value="Program Reguler">Program Reguler </option>
            </select>
          </div>
        </div>


        </div>
      </div>
    </div>


    <div class="col-md-6">
      <div class="tile">
        <h3 class="tile-title"> Edit Data Siswa </h3>
        <div class="tile-body">


          <input type="hidden" name="idnya" value="<?php echo $data['id']; ?>">



            <div class="form-group row">
              <label class="control-label col-md-3">Nama Peserta</label>
              <div class="col-md-8">
                <input class="form-control" type="text" name="namaPeserta" value="<?php echo $data['nama_peserta']; ?>">
              </div>
            </div>
            <div class="form-group row">
              <label class="control-label col-md-3">NISN</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="nisn" value="<?php echo $data['nisn']; ?>">
              </div>
            </div>
            <div class="form-group row">
              <label class="control-label col-md-3">Asal Sekolah</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="asalSekolah" value="<?php echo $data['asal_sekolah']; ?>">
              </div>
            </div>
            <div class="form-group row">
              <label class="control-label col-md-3">Tempat lahir</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="tempatLahir" value="<?php echo $data['tempat_lahir']; ?>">
              </div>
            </div>

            <div class="form-group row">
              <label class="control-label col-md-3">Tanggal lahir</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="tanggalLahir" value="<?php echo $data['tanggal_lahir']; ?>">
              </div>
            </div>

            <div class="form-group row">
              <label class="control-label col-md-3">Bulan lahir</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="bulanLahir" value="<?php echo $data['bulan_lahir']; ?>">
              </div>
            </div>

            <div class="form-group row">
              <label class="control-label col-md-3">Tahun lahir</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" id="tahunLahir" type="text" name="tahunLahir" value="<?php echo $data['tahun_lahir']; ?>">
              </div>
            </div>

            <div class="form-group row">
              <label class="control-label col-md-3">Alamat Rumah</label>
              <div class="col-md-8">
                <textarea class="form-control" rows="4" name="alamat"> <?php echo $data['alamat']; ?> </textarea>
              </div>
            </div>

            <div class="form-group row">
              <label class="control-label col-md-3">Kecamatan</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="kecamatan" value="<?php echo $data['kecamatan']; ?>">
              </div>
            </div>

            <div class="form-group row">
              <label class="control-label col-md-3">Kabupaten</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="kabupaten" value="<?php echo $data['kabupaten']; ?>">
              </div>
            </div>

            <div class="form-group row">
              <label class="control-label col-md-3">Jenis Kelamin</label>
              <div class="col-md-8">
                <form>
                  <input class="form-control col-md-8" type="text" name="gender" value="<?php echo $data['jenis_kelamin']; ?>">
                </form>
              </div>
            </div>


            <div class="form-group row">
              <label class="control-label col-md-3">Umur</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" id="umur" name="umur" value="<?php echo $data['umur']; ?>">
              </div>
            </div>

            <div class="form-group row">
              <label class="control-label col-md-3">Agama</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="agama" value="<?php echo $data['agama']; ?>">
              </div>
            </div> <br> <br>



        </div>
      </div>
    </div>


    <div class="col-md-6">
      <div class="tile">
        <h3 class="tile-title"> Edit Data Orang tua </h3>
        <div class="tile-body">

            <div class="form-group row">
              <label class="control-label col-md-3">Nama Ayah</label>
              <div class="col-md-8">
                <input class="form-control" type="text" name="namaAyah" value="<?php echo $data['nama_ayah']; ?>">
              </div>
            </div>
            <div class="form-group row">
              <label class="control-label col-md-3">Pekerjaan Ayah</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="pekerjaanAyah" value="<?php echo $data['pekerjaan_ayah']; ?>">
              </div>
            </div>
            <div class="form-group row">
              <label class="control-label col-md-3">Nama Ibu</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="namaIbu" value="<?php echo $data['nama_ibu']; ?>">
              </div>
            </div>
            <div class="form-group row">
              <label class="control-label col-md-3">Pekerjaan Ibu</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="pekerjaanIbu" value="<?php echo $data['pekerjaan_ibu']; ?>">
              </div>
            </div>

            <div class="form-group row">
              <label class="control-label col-md-3">Alamat Rumah</label>
              <div class="col-md-8">
                <textarea class="form-control" rows="4" name="alamatOrtu"> <?php echo $data['alamat_rumah_ortu']; ?> </textarea>
              </div>
            </div>

            <div class="form-group row">
              <label class="control-label col-md-3">Kecamatan</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="kecamatanOrtu" value="<?php echo $data['kecamatan_ortu']; ?>">
              </div>
            </div>

            <div class="form-group row">
              <label class="control-label col-md-3">Kabupaten</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="kabupatenOrtu" value="<?php echo $data['kabupaten_ortu']; ?>">
              </div>
            </div>

            <div class="form-group row">
              <label class="control-label col-md-3">No Telp 1</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="telp1" value="<?php echo $data['telp1']; ?>">
              </div>
            </div>

            <div class="form-group row">
              <label class="control-label col-md-3">No WA</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="telp2" value="<?php echo $data['wa']; ?>">
              </div>
            </div> <br> <br> <br><br> <br>
        </div>

      </div>

    </div>


    <div class="clearix"></div>
    <div class="col-md-12">
      <div class="tile">
        <h3 class="tile-title">Edit Data Nilai</h3>
        <div class="tile-body">

          <div class="container">
            <table class="table table-striped">
              <tr>
                <th colspan="2" style="text-align:center; background-color:#3498db; color:white;  ">Kelas 4</th>
                <th colspan="2" style="text-align:center; background-color:#3498db; color:white; ">Kelas 5</th>
                <th colspan="2" style="text-align:center; background-color:#3498db; color:white; ">Kelas 6</th>
                <th colspan="2" rowspan="2" style="text-align:center; background-color:#2980b9; color:white; "> Rata-rata Akhir </th>
              </tr>
              <tr>
                <td>semester 1</td>
                <td>semester 2</td>
                <td>semester 1</td>
                <td>semester 2</td>
                <td colspan="2">semester 1</td>
              </tr>

              <tr>
                <td><input type="text" class="form-control form-qu" id="kelas4smt1" name="kelas4smt1" value="<?php echo $data['nilai_kelas_4_smt_1']; ?>"></td>
                <td><input type="text" class="form-control form-qu" id="kelas4smt2" name="kelas4smt2" value="<?php echo $data['nilai_kelas_4_smt_2']; ?>"></td>

                <td><input type="text" class="form-control form-qu" id="kelas5smt1" name="kelas5smt1" value="<?php echo $data['nilai_kelas_5_smt_1']; ?>"></td>
                <td><input type="text" class="form-control form-qu" id="kelas5smt2" name="kelas5smt2" value="<?php echo $data['nilai_kelas_5_smt_2']; ?>"></td>

                <td><input type="text" class="form-control form-qu" id="kelas6smt1" name="kelas6smt1" value="<?php echo $data['nilai_kelas_6_smt_1']; ?>"></td>

                <td colspan="2"><input type="text" class="form-control form-qu" id="rataRata" name="rataRata" value="<?php echo $data['rata_rata_final']; ?>"></td>
              </tr>

            </table>
          </div>

        </div>
      </div>
    </div>

    <div class="col-md-12">
      <input type="submit" name="update" value="Update data" class="btn btn-info" style="width:100%;">
    </div>


  </form>

  <!-- tutup while -->
  <?php } ?>

  <!-- Update data -->
  <?php
    $cek = editUser(

          $idnya, $programPertama,$programKedua,$namaPeserta,$nisn,$asalSekolah,$tempatLahir,$tanggalLahir,$bulanLahir,$tahunLahir,$alamat,$kecamatan,$kabupaten,$umur,$agama,$gender,$namaAyah,$pekerjaanAyah,$namaIbu,$pekerjaanIbu,$alamatOrtu,$kecOrtu,$kabOrtu,$telp1, $wa,
          $kelas4smt1,
          $kelas4smt2,
          $kelas5smt1,
          $kelas5smt2,
          $kelas6smt1,
          $rataRata

        );
  ?>


  </div>





</main>




<!-- Javascripts-->
<!-- Essential javascripts for application to work-->
<script src="../assets/js/jquery-3.2.1.min.js"></script>
<script src="../assets/js/popper.min.js"></script>

<script src="../functions/functions.js"></script>

<script src="../assets/js/bootstrap.min.js"></script>
<script src="../assets/js/main.js"></script>
<!-- The javascript plugin to display page loading on top-->
<script src="../assets/js/plugins/pace.min.js"></script>

<script src="../assets/js/plugins/pace.min.js"></script>
<!-- Page specific javascripts-->
<!-- Data table plugin-->
<script type="text/javascript" src="../assets/js/plugins/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../assets/js/plugins/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">$('#sampleTable').DataTable();</script>

<!-- Page specific javascripts-->
<script type="text/javascript" src="../assets/js/plugins/chart.js"></script>
<script type="text/javascript">
  var data = {
    labels: ["January", "February", "March", "April", "May"],
    datasets: [
      {
        label: "My First dataset",
        fillColor: "rgba(220,220,220,0.2)",
        strokeColor: "rgba(220,220,220,1)",
        pointColor: "rgba(220,220,220,1)",
        pointStrokeColor: "#fff",
        pointHighlightFill: "#fff",
        pointHighlightStroke: "rgba(220,220,220,1)",
        data: [65, 59, 80, 81, 56]
      },
      {
        label: "My Second dataset",
        fillColor: "rgba(151,187,205,0.2)",
        strokeColor: "rgba(151,187,205,1)",
        pointColor: "rgba(151,187,205,1)",
        pointStrokeColor: "#fff",
        pointHighlightFill: "#fff",
        pointHighlightStroke: "rgba(151,187,205,1)",
        data: [28, 48, 40, 19, 86]
      }
    ]
  };
  var pdata = [
    {
      value: 300,
      color: "#46BFBD",
      highlight: "#5AD3D1",
      label: "Complete"
    },
    {
      value: 50,
      color:"#F7464A",
      highlight: "#FF5A5E",
      label: "In-Progress"
    }
  ]

  var ctxl = $("#lineChartDemo").get(0).getContext("2d");
  var lineChart = new Chart(ctxl).Line(data);

  var ctxp = $("#pieChartDemo").get(0).getContext("2d");
  var pieChart = new Chart(ctxp).Pie(pdata);
</script>
</body>
</html>
