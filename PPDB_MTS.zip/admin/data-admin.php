<?php
  include 'include/koneksi.php';
  include 'include/header.php';
?>


<main class="app-content">
  <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"></i> Data Admin</h1>
      <p>Anda bisa menambah, mengefit dan menghapus hak akses admin</p>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item">Tables</li>
      <li class="breadcrumb-item active"><a href="#">Data Table</a></li>
    </ul>
  </div>
  <div class="row">

    <div class="col-md-6">
      <input id="klikAdmin" type="submit" value="Tambah Admin" class="btn btn-info"> <br> <br>
    </div>

    <div class="col-md-12" id="tambahAdmin">
      <div class="tile">
        <div class="tile-body">

          <h4>Tambah Admin</h4> <br>


          <form action="" method="post">
            <div class="form-group row">
              <label class="control-label col-md-2">Nama Admin</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="namaAdmin" value=""  required>
              </div>
            </div>

            <div class="form-group row">
              <label class="control-label col-md-2">Username</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="username" value="" required>
              </div>
            </div>

            <div class="form-group row">
              <label class="control-label col-md-2">Password</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="password" value="" required>
              </div>
            </div>

            <input type="hidden" name="level" value="2">

            <input type="submit" name="daftarAdmin" value="Daftar" class="btn btn-success">

          </form>

          <?php
            if (isset($_POST['daftarAdmin'])) {
              $nama     = $_POST['namaAdmin'];
              $username = $_POST['username'];
              $level    = $_POST['level'];
              $pass     = $_POST['password'];
              $password = md5($pass);

              $query = mysqli_query($conn, "INSERT INTO tb_admin (nama,username,password,level ) VALUES('$nama','$username','$password','$level') ") or die(mysqli_error($conn));
              if ($query) {
                echo " <script> alert('Berhasil menambah admin'); </script> ";
              } else {
                echo " <script> alert('Oops, Ada kesalahan'); </script> ";
              }

            }
          ?>

        </div>
      </div>
    </div>

    <div class="col-md-12">
      <div class="tile">
        <div class="tile-body">
          <table class="table table-hover table-bordered" id="sampleTable">
            <thead>
              <tr>
                <th>No.</th>
                <th>Nama</th>
                <th>Username</th>
                <th>Level</th>
              </tr>
            </thead>
            <tbody>

              <?php
                $no    = 1;
                $query = mysqli_query($conn, "SELECT * FROM tb_admin ORDER BY id DESC");
                while ($data = mysqli_fetch_array($query)) {
              ?>

              <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $data['nama']; ?></td>
                <td><?php echo $data['username']; ?></td>
                <td><?php echo $data['level']; ?></td>

              </tr>

              <?php } ?>

            </tbody>
          </table>
        </div>
      </div>
    </div>


    <div class="col-md-12" id="editAdmin">
      <div class="tile">
        <div class="tile-body">

          <h4>Edit Admin</h4> <br>


          <form action="" method="post">
            <div class="form-group row">
              <label class="control-label col-md-2">Nama Admin</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="namaAdmin" value="">
              </div>
            </div>

            <div class="form-group row">
              <label class="control-label col-md-2">Username</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="username" value="">
              </div>
            </div>

            <div class="form-group row">
              <label class="control-label col-md-2">Password</label>
              <div class="col-md-8">
                <input class="form-control col-md-8" type="text" name="password" value="">
              </div>
            </div>

            <input type="hidden" name="level" value="2">

            <input type="submit" name="daftarAdmin" value="Daftar" class="btn btn-success">

          </form>

          <?php
            if (isset($_POST['daftarAdmin'])) {
              $nama     = $_POST['namaAdmin'];
              $username = $_POST['username'];
              $level    = $_POST['level'];
              $pass     = $_POST['password'];
              $password = md5($pass);

              $query = mysqli_query($conn, "INSERT INTO tb_admin (nama,username,password,level ) VALUES('$nama','$username','$password','$level') ") or die(mysqli_error($conn));
              if ($query) {
                echo " <script> alert('Berhasil menambah admin'); </script> ";
              } else {
                echo " <script> alert('Oops, Ada kesalahan'); </script> ";
              }

            }
          ?>

        </div>
      </div>
    </div>


  </div>
</main>


<?php
  include 'include/footer.php';
?>

<script>
  $(document).ready(function(){
    $("#tambahAdmin").hide();
    $("#editAdmin").hide();

    $("#klikAdmin").click(function(){
        $("#tambahAdmin").show();
    })

    $("#klikEditAdmin").click(function(){
        $("#editAdmin").show();
    })

  })
</script>
