<?php
  include 'include/header.php';
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Cara pendaftaran</title>
  </head>
  <body>

    <div class="container">
      <div class="row">
        <section id="alur" class="alur">
    			<div class="container">
    				<h3>Alur Pendaftaran</h3>
    				<div class="row">

    					<section class="main-timeline-section">
    			    <div class="timeline-start"></div>
    			    <div class="conference-center-line"></div>
    			    <div class="conference-timeline-content">
    				    <div class="timeline-article timeline-article-top">
    				        <div class="content-date">
    			          		<span> <a href="#" data-toggle="tooltip" title="Hooray!" > ceq </a> </span>
    				        </div>
    				        <div class="meta-date">  </div>
    				        <!-- <div class="content-box">
    				        	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
    				        </div> -->
    				    </div>

    				    <div class="timeline-article timeline-article-bottom">
    				        <div class="content-date">
    			          		<span>10-09-2017</span>
    				        </div>
    				        <div class="meta-date"></div>
    				        <!-- <div class="content-box">
    				        	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
    				        </div> -->
    				    </div>
    			      	 <div class="timeline-article timeline-article-top">
    				        <div class="content-date">
    			          		<span>10-09-2017</span>
    				        </div>
    				        <div class="meta-date"></div>
    				        <!-- <div class="content-box">
    				        	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
    				        </div> -->
    				    </div>

    				    <div class="timeline-article timeline-article-bottom">
    				        <div class="content-date">
    			          		<span>1. Buka Website</span>
    				        </div>
    				        <div class="meta-date"></div>
    				        <!-- <div class="content-box">
    				        	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
    				        </div> -->
    				    </div>
    			   	</div>
    			   	<div class="timeline-end"></div>
    		  	</section>



    				</div>
    			</div>

    		</section>

        <a href="daftar.php" class="btn btn-info" style="width:100%; color:white; padding:10px; font-size:18px;">Daftar Sekarang</a>

      </div>
    </div>

  </body>
</html>
