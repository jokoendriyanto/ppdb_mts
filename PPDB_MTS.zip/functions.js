$(document).ready(function(){

umur();
function umur(){

  $("input").keyup(function(){

    var date      = new Date();
    var tahun     = date.getFullYear();
    var tahunLahir = $("#tahunLahir").val()

    $("#umur").val( tahun - tahunLahir );

  })

}


rataRata();
function rataRata(){

  $("input").keyup(function(){


    var pertama = $("#kelas4smt1").val();
    var kedua   = $("#kelas4smt2").val();
    var ketiga  = $("#kelas5smt1").val();
    var keempat = $("#kelas5smt2").val();
    var kelima  = $("#kelas6smt1").val();

    var hasilrataRata = parseInt(pertama) + parseInt(kedua) + parseInt(ketiga) + parseInt(keempat) + parseInt(kelima);
    var hasilFinal    = hasilrataRata/5;

    $("#rataRata").val(hasilFinal);

  })

}



















})
